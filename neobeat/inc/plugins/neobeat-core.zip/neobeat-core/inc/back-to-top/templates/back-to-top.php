<a id="qodef-back-to-top" href="#">
    <span class="qodef-back-to-top-label"><?php esc_html_e( 'Back to top', 'neobeat-core' ); ?></span>
	<?php echo qode_framework_icons()->get_specific_icon_from_pack( 'back-to-top', 'ionicons', array( 'icon_attributes' => array( 'class' => 'qodef-back-to-top-icon' ) ) ); ?>
</a>
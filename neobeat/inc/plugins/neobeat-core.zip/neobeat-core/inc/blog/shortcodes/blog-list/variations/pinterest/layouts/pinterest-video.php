<?php
$video_link = get_post_meta( get_the_ID(), 'qodef_post_format_video_url', true );
?>

<article <?php post_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<?php
		neobeat_core_template_part( 'blog/shortcodes/blog-list', 'templates/post-info/image', 'background', $params );
		?>
		<?php if ( ! empty( $video_link ) ) { ?>
			<div class="qodef-e-play">
				<span class="qodef-e-play-inner">
					<span class="qodef-e-play-inner-bg-holder"></span>
					<?php echo qode_framework_icons()->render_icon( 'ion-ios-play', 'ionicons' ); ?>
					<?php echo qode_framework_icons()->render_icon( 'ion-ios-play', 'ionicons' ); ?>
				</span>
			</div>
		<?php } ?>
		<?php neobeat_core_template_part( 'blog/shortcodes/blog-list', 'templates/post-info/link' ); ?>
	</div>
</article>
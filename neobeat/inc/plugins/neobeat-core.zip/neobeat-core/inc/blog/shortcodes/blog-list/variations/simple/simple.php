<?php

if ( ! function_exists( 'neobeat_core_add_blog_list_variation_simple' ) ) {
	function neobeat_core_add_blog_list_variation_simple( $variations ) {
		$variations['simple'] = esc_html__( 'Simple', 'neobeat-core' );
		
		return $variations;
	}
	
	add_filter( 'neobeat_core_filter_blog_list_layouts', 'neobeat_core_add_blog_list_variation_simple' );
}
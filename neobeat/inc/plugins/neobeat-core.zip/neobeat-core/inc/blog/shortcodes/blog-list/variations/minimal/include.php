<?php

include_once 'minimal.php';
<?php

if ( ! function_exists( 'neobeat_core_add_blog_list_variation_pinterest' ) ) {
	function neobeat_core_add_blog_list_variation_pinterest( $variations ) {
		$variations['pinterest'] = esc_html__( 'Pinterest', 'neobeat-core' );
		
		return $variations;
	}
	
	add_filter( 'neobeat_core_filter_blog_list_layouts', 'neobeat_core_add_blog_list_variation_pinterest' );
}

if ( ! function_exists( 'neobeat_core_load_blog_list_variation_pinterest_assets' ) ) {
	function neobeat_core_load_blog_list_variation_pinterest_assets( $is_enabled, $params ) {
		
		if ( $params['layout'] === 'pinterest' ) {
			$is_enabled = true;
		}
		
		return $is_enabled;
	}
	
	add_filter( 'neobeat_core_filter_load_blog_list_assets', 'neobeat_core_load_blog_list_variation_pinterest_assets', 10, 2 );
}
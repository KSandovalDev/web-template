(function ($) {
	"use strict";
	
	var shortcode = 'neobeat_core_instagram_list';
	
	qodefCore.shortcodes[shortcode] = {};
	
	if (typeof qodefCore.listShortcodesScripts === 'object') {
		$.each(qodefCore.listShortcodesScripts, function (key, value) {
			qodefCore.shortcodes[shortcode][key] = value;
		});
	}
	
	$(document).ready(function () {
		qodefAddBlurClasses.init();
	});
	
	var qodefAddBlurClasses = {
		init: function () {
			var item = $('.qodef-instagram-list').find('.sbi_photo_wrap');
				item.addClass('qodef-e-blur-trigger').find('a').addClass('qodef-e-blur-target');
		}
	};
	
	qodefCore.shortcodes.neobeat_core_instagram_list.qodefAddBlurClasses = qodefAddBlurClasses;
	
})(jQuery);

<?php do_action('neobeat_action_before_page_header'); ?>

<header id="qodef-page-header">
	<a href="javascript:void(0)" class="qodef-vertical-closed-menu-opener <?php echo neobeat_core_get_open_close_icon_class('qodef_fullscreen_menu_icon_source','qodef-vertical-closed-menu-opener') ?>">
		<span class="qodef-open-icon">
			<?php echo neobeat_core_get_fullscreen_icon_html(); ?>
		</span>
		<span class="qodef-close-icon">
			<?php echo neobeat_core_get_fullscreen_icon_html(true); ?>
		</span>
	</a>
    <div id="qodef-page-header-inner">
	    <?php neobeat_core_get_header_logo_image(); ?>
		<?php neobeat_core_template_part( 'header', 'layouts/vertical/templates/navigation' ); ?>
		<div class="qodef-vertical-closed-widget-holder">
			<?php neobeat_core_get_header_widget_area(); ?>
		</div>
    </div>
</header>

(function ($) {
	"use strict";
	
	$(document).ready(function () {
		qodefVerticalClosedNavMenu.init();
	});
	
	/**
	 * Function object that represents vertical menu area.
	 * @returns {{init: Function}}
	 */
	var qodefVerticalClosedNavMenu = {
		initNavigation: function ($verticalMenuObject) {
			var $verticalNavObject = $verticalMenuObject.find('.qodef-header-vertical-navigation');
			
			if ($verticalNavObject.hasClass('qodef-vertical-drop-down--below')) {
				qodefVerticalClosedNavMenu.dropdownClickToggle($verticalNavObject);
			} else if ($verticalNavObject.hasClass('qodef-vertical-drop-down--side')) {
				qodefVerticalClosedNavMenu.dropdownFloat($verticalNavObject);
			}
		},
		dropdownClickToggle: function ($verticalNavObject) {
			var $menuItems = $verticalNavObject.find('ul li.menu-item-has-children');
			
			$menuItems.each(function () {
				var $elementToExpand = $(this).find(' > .qodef-drop-down-second, > ul');
				var menuItem = this;
				var $dropdownOpener = $(this).find('> a');
				var slideUpSpeed = 'fast';
				var slideDownSpeed = 'slow';
				
				$dropdownOpener.on('click tap', function (e) {
					e.preventDefault();
					e.stopPropagation();
					
					if ($elementToExpand.is(':visible')) {
						$(menuItem).removeClass('qodef-menu-item--open');
						$elementToExpand.slideUp(slideUpSpeed);
					} else if ($dropdownOpener.parent().parent().children().hasClass('qodef-menu-item--open') && $dropdownOpener.parent().parent().parent().hasClass('qodef-vertical-menu')) {
						$(this).parent().parent().children().removeClass('qodef-menu-item--open');
						$(this).parent().parent().children().find(' > .qodef-drop-down-second').slideUp(slideUpSpeed);
						
						$(menuItem).addClass('qodef-menu-item--open');
						$elementToExpand.slideDown(slideDownSpeed);
					} else {
						
						if (!$(this).parents('li').hasClass('qodef-menu-item--open')) {
							$menuItems.removeClass('qodef-menu-item--open');
							$menuItems.find(' > .qodef-drop-down-second, > ul').slideUp(slideUpSpeed);
						}
						
						if ($(this).parent().parent().children().hasClass('qodef-menu-item--open')) {
							$(this).parent().parent().children().removeClass('qodef-menu-item--open');
							$(this).parent().parent().children().find(' > .qodef-drop-down-second, > ul').slideUp(slideUpSpeed);
						}
						
						$(menuItem).addClass('qodef-menu-item--open');
						$elementToExpand.slideDown(slideDownSpeed);
					}
				});
			});
		},
		dropdownFloat: function ($verticalNavObject) {
			var $menuItems = $verticalNavObject.find('ul li.menu-item-has-children');
			var $allDropdowns = $menuItems.find(' > .qodef-drop-down-second > .qodef-drop-down-second-inner > ul, > ul');
			
			$menuItems.each(function () {
				var $elementToExpand = $(this).find(' > .qodef-drop-down-second > .qodef-drop-down-second-inner > ul, > ul');
				var menuItem = this;
				
				if (Modernizr.touch) {
					var $dropdownOpener = $(this).find('> a');
					
					$dropdownOpener.on('click tap', function (e) {
						e.preventDefault();
						e.stopPropagation();
						
						if ($elementToExpand.hasClass('qodef-float--open')) {
							$elementToExpand.removeClass('qodef-float--open');
							$(menuItem).removeClass('qodef-menu-item--open');
						} else {
							if (!$(this).parents('li').hasClass('qodef-menu-item--open')) {
								$menuItems.removeClass('qodef-menu-item--open');
								$allDropdowns.removeClass('qodef-float--open');
							}
							
							$elementToExpand.addClass('qodef-float--open');
							$(menuItem).addClass('qodef-menu-item--open');
						}
					});
				} else {
					//must use hoverIntent because basic hover effect doesn't catch dropdown
					//it doesn't start from menu item's edge
					$(this).hoverIntent({
						over: function () {
							$elementToExpand.addClass('qodef-float--open');
							$(menuItem).addClass('qodef-menu-item--open');
						},
						out: function () {
							$elementToExpand.removeClass('qodef-float--open');
							$(menuItem).removeClass('qodef-menu-item--open');
						},
						timeout: 300
					});
				}
			});
		},
		verticalAreaScrollable: function ($verticalMenuObject) {
			return $verticalMenuObject.hasClass('qodef-with-scroll');
		},
		initVerticalAreaScroll: function ($verticalMenuObject) {
			if (qodefVerticalClosedNavMenu.verticalAreaScrollable($verticalMenuObject)) {
				window.qodefCore.qodefPerfectScrollbar.init($verticalMenuObject);
			}
		},
		initHiddenVerticalArea : function( $verticalMenuObject ) {
			var verticalLogo = $('.edge-vertical-area-bottom-logo');
			var verticalMenuOpener = $verticalMenuObject.find('.qodef-vertical-closed-menu-opener');
			var scrollPosition = 0;
			
			verticalMenuOpener.on('click tap', function() {
				if(isVerticalAreaOpen()) {
					closeVerticalArea();
				} else {
					openVerticalArea();
				}
			});
			
			$(window).scroll(function() {
				if(Math.abs($(window).scrollTop() - scrollPosition) > 400){
					closeVerticalArea();
				}
			});
			
			/**
			 * Closes vertical menu area by removing 'active' class on that element
			 */
			function closeVerticalArea() {
				$verticalMenuObject.removeClass('active');
				
				if(verticalLogo.length) {
					verticalLogo.removeClass('active');
				}
			}
			
			/**
			 * Opens vertical menu area by adding 'active' class on that element
			 */
			function openVerticalArea() {
				$verticalMenuObject.addClass('active');
				
				if(verticalLogo.length) {
					verticalLogo.addClass('active');
				}
				scrollPosition = $(window).scrollTop();
			}
			
			function isVerticalAreaOpen() {
				return $verticalMenuObject.hasClass('active');
			}
		},
		init: function () {
			var $verticalMenuObject = $('.qodef-header--vertical-closed #qodef-page-header');
			
			if ($verticalMenuObject.length) {
				qodefVerticalClosedNavMenu.initNavigation($verticalMenuObject);
				qodefVerticalClosedNavMenu.initVerticalAreaScroll($verticalMenuObject);
				qodefVerticalClosedNavMenu.initHiddenVerticalArea($verticalMenuObject);
			}
		}
	};
	
})(jQuery);
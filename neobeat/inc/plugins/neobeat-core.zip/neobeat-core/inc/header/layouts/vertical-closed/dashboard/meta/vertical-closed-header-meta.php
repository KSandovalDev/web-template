<?php

if ( ! function_exists( 'neobeat_core_add_vertical_closed_header_meta' ) ) {
	function neobeat_core_add_vertical_closed_header_meta( $page ) {

		$section = $page->add_section_element(
			array(
				'name'       => 'qodef_vertical_closed_header_section',
				'title'      => esc_html__( 'Closed Vertical Header', 'neobeat-core' ),
				'dependency' => array(
					'show' => array(
						'qodef_header_layout' => array(
							'values' => 'vertical-closed',
							'default_value' => ''
						)
					)
				)
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'color',
				'name'        => 'qodef_vertical-closed_header_background_color',
				'title'       => esc_html__( 'Header Background Color', 'neobeat-core' ),
				'description' => esc_html__( 'Enter header background color', 'neobeat-core' )
			)
		);

	}
	
	add_action( 'neobeat_core_action_after_page_header_meta_map', 'neobeat_core_add_vertical_closed_header_meta' );
}
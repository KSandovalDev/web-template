<?php
include_once 'helper.php';
include_once 'vertical-closed-header.php';
include_once 'dashboard/admin/vertical-closed-header-options.php';
include_once 'dashboard/meta/vertical-closed-header-meta.php';
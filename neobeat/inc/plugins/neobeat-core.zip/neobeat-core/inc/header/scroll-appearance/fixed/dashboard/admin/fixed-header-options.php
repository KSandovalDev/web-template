<?php

if ( ! function_exists( 'neobeat_core_add_fixed_header_options' ) ) {
	function neobeat_core_add_fixed_header_options( $page ) {
	
	}
	
	add_action( 'neobeat_core_action_after_header_options_map', 'neobeat_core_add_fixed_header_options' );
}
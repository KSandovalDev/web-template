<div class="qodef-header-sticky">
	<div class="qodef-header-sticky-inner <?php echo apply_filters( 'neobeat_filter_header_inner_class', '' ); ?>">
		<div class="qodef-header-wrapper">
			<div class="qodef-header-logo-wrapper">
				<?php neobeat_core_get_header_logo_image(); ?>
			</div>
			<?php neobeat_core_template_part( 'header', 'templates/parts/navigation', '', array( 'menu_id' => 'qodef-sticky-navigation-menu' ) );
			?>
			<div class="qodef-widget-holder">
				<?php neobeat_core_get_header_widget_area( 'sticky' ); ?>
			</div>
			<?php do_action( 'neobeat_core_action_after_sticky_header' ); ?>
		</div>
	</div>
</div>
<?php

if ( ! function_exists( 'neobeat_core_get_fullscreen_icon_html' ) ) {
	/**
	 * Returns html for icon sources
	 * @param bool $is_close_icon
	 *
	 * @return string/html
	 */
	function neobeat_core_get_fullscreen_icon_html($is_close_icon = false) {
		$html = '';

		$icon_source         = neobeat_core_get_option_value('admin', 'qodef_fullscreen_menu_icon_source' );
		$icon_pack           = neobeat_core_get_option_value('admin', 'qodef_fullscreen_menu_icon_pack' );
		$icon_svg_path       = neobeat_core_get_option_value('admin', 'qodef_fullscreen_menu_icon_svg_path' );
		$close_icon_svg_path = neobeat_core_get_option_value('admin', 'qodef_fullscreen_menu_close_icon_svg_path' );


		if ( $icon_source === 'icon_pack' && !empty( $icon_pack ) ) {
			if ( $is_close_icon ) {
				$html .= qode_framework_icons()->get_specific_icon_from_pack('close', $icon_pack);

			} else {
				$html .= qode_framework_icons()->get_specific_icon_from_pack('menu', $icon_pack);
			}

		} elseif ( $icon_source === 'svg_path' && ((isset( $icon_svg_path ) && ! empty( $icon_svg_path ) ) || ( isset($close_icon_svg_path) && ! empty($close_icon_svg_path))) ) {

			if ( $is_close_icon ) {
				$html .= $close_icon_svg_path;
			} else {
				$html .= $icon_svg_path;
			}

		} elseif ( $icon_source === 'predefined' ) {
			$html .= '<span class="qodef-circles">';
			$html .= '<span class="qodef-circles-row qodef-cr-1"><span class="qodef-circle"></span>';
			$html .= '<span class="qodef-circle"></span>';
			$html .= '<span class="qodef-circle"></span></span>';
			$html .= '<span class="qodef-circles-row qodef-cr-2"><span class="qodef-circle"></span>';
			$html .= '<span class="qodef-circle"></span>';
			$html .= '<span class="qodef-circle"></span></span>';
			$html .= '<span class="qodef-circles-row qodef-cr-3"><span class="qodef-circle"></span>';
			$html .= '<span class="qodef-circle"></span>';
			$html .= '<span class="qodef-circle"></span></span>';
			$html .= '</span>';
		}


		return $html;
	}
}

if ( ! function_exists( 'neobeat_core_register_fullscreen_menu' ) ) {
	function neobeat_core_register_fullscreen_menu($menus) {

		$menus['fullscreen-menu-navigation'] = esc_html__( 'Fullscreen Navigation', 'neobeat-core' );

		return $menus;
	}
	add_filter('neobeat_filter_register_navigation_menus','neobeat_core_register_fullscreen_menu');
}

if ( ! function_exists( 'neobeat_core_set_fullscreen_menu_styles' ) ) {
	/**
	 * Function that generates fullscreen menu inline styles
	 *
	 * @param $style string
	 *
	 * @return string
	 */
	function neobeat_core_set_fullscreen_menu_styles( $style ) {
		$fullscreen_menu_styles = array();
		
		$fullscreen_menu_background_image        = neobeat_core_get_post_value_through_levels( 'qodef_fullscreen_menu_background_image' );
		$fullscreen_menu_background_image_repeat = neobeat_core_get_post_value_through_levels( 'qodef_fullscreen_menu_background_image_repeat' );
		$fullscreen_menu_background_image_size   = neobeat_core_get_post_value_through_levels( 'qodef_fullscreen_menu_background_image_size' );
		
		if ( ! empty( $fullscreen_menu_background_image ) ) {
			$fullscreen_menu_styles['background-image'] = 'url(' . esc_url( wp_get_attachment_image_url( $fullscreen_menu_background_image, 'full' ) ) . ')';
		}
		
		if ( ! empty( $fullscreen_menu_background_image ) && ! empty( $fullscreen_menu_background_image_repeat ) ) {
			$fullscreen_menu_styles['background-repeat'] = $fullscreen_menu_background_image_repeat;
		}
		
		if ( ! empty( $fullscreen_menu_background_image ) && ! empty( $fullscreen_menu_background_image_size ) ) {
			$fullscreen_menu_styles['background-size'] = $fullscreen_menu_background_image_size;
		}
		
		if ( ! empty( $fullscreen_menu_styles ) ) {
			$style .= qode_framework_dynamic_style( '.qodef-fullscreen-menu-holder', $fullscreen_menu_styles );
		}
		
		return $style;
	}
	
	add_filter( 'neobeat_filter_add_inline_style', 'neobeat_core_set_fullscreen_menu_styles' );
}
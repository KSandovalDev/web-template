<?php
$bg_image = neobeat_core_get_post_value_through_levels( 'qodef_fullscreen_menu_background_image' );

if ( ! empty( $bg_image ) ) {
	$holder_classes = 'qodef-has-bg-image';
}
?>

<div class="qodef-fullscreen-menu-holder <?php echo esc_html( $holder_classes ) ?>">
	<?php if ( $fullscreen_menu_in_grid ) : ?>
	<div class="qodef-content-grid">
		<?php endif; ?>
		<div class="qodef-fullscreen-menu-holder-inner">
			<?php if ( has_nav_menu( 'fullscreen-menu-navigation' ) ) : ?>
				<nav class="qodef-fullscreen-menu">
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'fullscreen-menu-navigation',
							'menu_id'        => 'qodef-fullscreen-menu-navigation-menu',
							'walker'         => new NeoBeatCoreRootMainMenuWalker()
						)
					);
					?>
				</nav>
			<?php endif; ?>
		</div>
		<?php if ( $fullscreen_menu_in_grid ) : ?>
	</div>
<?php endif; ?>
</div>
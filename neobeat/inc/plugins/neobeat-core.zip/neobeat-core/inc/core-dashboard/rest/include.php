<?php

include_once NEOBEAT_CORE_INC_PATH . '/core-dashboard/rest/rest.php';
<?php

if ( ! function_exists( 'neobeat_core_add_page_footer_meta_box' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function neobeat_core_add_page_footer_meta_box( $page ) {
		
		if ( $page ) {
			
			$footer_tab = $page->add_tab_element(
				array(
					'name'        => 'tab-footer',
					'icon'        => 'fa fa-cog',
					'title'       => esc_html__( 'Footer Settings', 'neobeat-core' ),
					'description' => esc_html__( 'Footer layout settings', 'neobeat-core' )
				)
			);
			
			$footer_tab->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_enable_page_footer',
					'title'       => esc_html__( 'Enable Page Footer', 'neobeat-core' ),
					'description' => esc_html__( 'Use this option to enable/disable page footer', 'neobeat-core' ),
					'options'     => neobeat_core_get_select_type_options_pool( 'no_yes' )
				)
			);
			
			$page_footer_section = $footer_tab->add_section_element(
				array(
					'name'       => 'qodef_page_footer_section',
					'title'      => esc_html__( 'Footer Area', 'neobeat-core' ),
					'dependency' => array(
						'hide' => array(
							'qodef_enable_page_footer' => array(
								'values'        => 'no',
								'default_value' => ''
							)
						)
					)
				)
			);
			
			$page_footer_section->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_footer_skin',
					'title'       => esc_html__( 'Footer Skin', 'neobeat-core' ),
					'description' => esc_html__( 'Choose a predefined style for footer elements', 'neobeat-core' ),
					'options'     => array(
						''      => esc_html__( 'Default', 'neobeat-core' ),
						'light' => esc_html__( 'Light', 'neobeat-core' )
					)
				)
			);
			
			// Top Footer Area Section
			
			$page_footer_section->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_enable_top_footer_area',
					'title'       => esc_html__( 'Enable Top Footer Area', 'neobeat-core' ),
					'description' => esc_html__( 'Use this option to enable/disable top footer area', 'neobeat-core' ),
					'options'     => neobeat_core_get_select_type_options_pool( 'no_yes' )
				)
			);
			
			$top_footer_area_section = $page_footer_section->add_section_element(
				array(
					'name'       => 'qodef_top_footer_area_section',
					'title'      => esc_html__( 'Top Footer Area', 'neobeat-core' ),
					'dependency' => array(
						'hide' => array(
							'qodef_enable_top_footer_area' => array(
								'values'        => 'no',
								'default_value' => ''
							)
						)
					)
				)
			);
			
			$top_footer_area_section->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_set_footer_top_area_in_grid',
					'title'         => esc_html__( 'Top Footer Area in Grid', 'neobeat-core' ),
					'description'   => esc_html__( 'Enabling this option will set page top footer area to be in grid', 'neobeat-core' ),
					'options'       => neobeat_core_get_select_type_options_pool( 'no_yes' )
				)
			);
			
			$custom_sidebars = neobeat_core_get_custom_sidebars();
			if ( ! empty( $custom_sidebars ) && count( $custom_sidebars ) > 1 ) {
				for ( $i = 1; $i <= 4; $i ++ ) {
					$top_footer_area_section->add_field_element(
						array(
							'field_type'  => 'select',
							'name'        => 'qodef_footer_top_custom_widget_area_' . $i,
							'title'       => sprintf( esc_html__( 'Custom Footer Top Area - Column %s', 'neobeat-core' ), $i ),
							'description' => sprintf( esc_html__( 'Widgets added here will appear in the %s column of top footer area', 'neobeat-core' ), $i ),
							'options'     => $custom_sidebars
						)
					);
				}
			}
			
			$top_footer_area_styles_section = $top_footer_area_section->add_section_element(
				array(
					'name'       => 'qodef_top_footer_area_styles_section',
					'title'      => esc_html__( 'Top Footer Area Styles', 'neobeat-core' )
				)
			);
			
			$top_footer_area_styles_section->add_field_element(
				array(
					'field_type' => 'select',
					'name'       => 'qodef_top_footer_area_content_alignment',
					'title'      => esc_html__( 'Content Alignment', 'neobeat-core' ),
					'options'     => array(
						''       => esc_html__( 'Default', 'neobeat-core' ),
						'center' => esc_html__( 'Center', 'neobeat-core' ),
						'right'  => esc_html__( 'Right', 'neobeat-core' )
					)
				)
			);
			
			$top_footer_area_styles_section->add_field_element(
				array(
					'field_type' => 'color',
					'name'       => 'qodef_top_footer_area_background_color',
					'title'      => esc_html__( 'Background Color', 'neobeat-core' )
				)
			);
			
			$top_footer_area_styles_section->add_field_element(
				array(
					'field_type' => 'image',
					'name'       => 'qodef_top_footer_area_background_image',
					'title'      => esc_html__( 'Background Image', 'neobeat-core' ),
					'multiple'   => 'no'
				)
			);
			
			$top_footer_area_styles_section->add_field_element(
				array(
					'field_type' => 'color',
					'name'       => 'qodef_top_footer_area_top_border_color',
					'title'      => esc_html__( 'Top Border Color', 'neobeat-core' )
				)
			);
			
			$top_footer_area_styles_section->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_top_footer_area_top_border_width',
					'title'      => esc_html__( 'Top Border Width', 'neobeat-core' ),
					'args'       => array(
						'suffix' => esc_html__( 'px', 'neobeat-core' )
					)
				)
			);
			
			// Bottom Footer Area Section
			
			$page_footer_section->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_enable_bottom_footer_area',
					'title'         => esc_html__( 'Enable Bottom Footer Area', 'neobeat-core' ),
					'description'   => esc_html__( 'Use this option to enable/disable bottom footer area', 'neobeat-core' ),
					'options'       => neobeat_core_get_select_type_options_pool( 'no_yes' )
				)
			);
			
			$bottom_footer_area_section = $page_footer_section->add_section_element(
				array(
					'name'       => 'qodef_bottom_footer_area_section',
					'title'      => esc_html__( 'Bottom Footer Area', 'neobeat-core' ),
					'dependency' => array(
						'hide' => array(
							'qodef_enable_bottom_footer_area' => array(
								'values'        => 'no',
								'default_value' => ''
							)
						)
					)
				)
			);
			
			$bottom_footer_area_section->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_set_footer_bottom_area_in_grid',
					'title'         => esc_html__( 'Bottom Footer Area in Grid', 'neobeat-core' ),
					'description'   => esc_html__( 'Enabling this option will set page bottom footer area to be in grid', 'neobeat-core' ),
					'options'       => neobeat_core_get_select_type_options_pool( 'no_yes' )
				)
			);
			
			if ( ! empty( $custom_sidebars ) && count( $custom_sidebars ) > 1 ) {
				for ( $i = 1; $i <= 2; $i ++ ) {
					$bottom_footer_area_section->add_field_element(
						array(
							'field_type'  => 'select',
							'name'        => 'qodef_footer_bottom_custom_widget_area_' . $i,
							'title'       => sprintf( esc_html__( 'Custom Footer Bottom Area - Column %s', 'neobeat-core' ), $i ),
							'description' => sprintf( esc_html__( 'Widgets added here will appear in the %s column of bottom footer area', 'neobeat-core' ), $i ),
							'options'     => $custom_sidebars
						)
					);
				}
			}
			
			$bottom_footer_area_styles_section = $bottom_footer_area_section->add_section_element(
				array(
					'name'       => 'qodef_bottom_footer_area_styles_section',
					'title'      => esc_html__( 'Bottom Footer Area Styles', 'neobeat-core' )
				)
			);
			
			$bottom_footer_area_styles_section->add_field_element(
				array(
					'field_type' => 'select',
					'name'       => 'qodef_bottom_footer_area_content_alignment',
					'title'      => esc_html__( 'Content Alignment', 'neobeat-core' ),
					'options'     => array(
						''       => esc_html__( 'Default', 'neobeat-core' ),
						'center' => esc_html__( 'Center', 'neobeat-core' ),
						'right'  => esc_html__( 'Right', 'neobeat-core' )
					)
				)
			);
			
			$bottom_footer_area_styles_section->add_field_element(
				array(
					'field_type' => 'color',
					'name'       => 'qodef_bottom_footer_area_background_color',
					'title'      => esc_html__( 'Background Color', 'neobeat-core' )
				)
			);
			
			$bottom_footer_area_styles_section->add_field_element(
				array(
					'field_type' => 'color',
					'name'       => 'qodef_bottom_footer_area_top_border_color',
					'title'      => esc_html__( 'Top Border Color', 'neobeat-core' )
				)
			);
			
			$bottom_footer_area_styles_section->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_bottom_footer_area_top_border_width',
					'title'      => esc_html__( 'Top Border Width', 'neobeat-core' ),
					'args'       => array(
						'suffix' => esc_html__( 'px', 'neobeat-core' )
					)
				)
			);
			
			// Hook to include additional options after module options
			do_action( 'neobeat_core_action_after_page_footer_meta_box_map', $footer_tab );
		}
	}
	
	add_action( 'neobeat_core_action_after_general_meta_box_map', 'neobeat_core_add_page_footer_meta_box' );
}
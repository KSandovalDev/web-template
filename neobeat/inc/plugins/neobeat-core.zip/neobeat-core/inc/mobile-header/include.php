<?php

include_once 'mobile-header.php';
include_once 'mobile-headers.php';
include_once 'template-functions.php';
<a id="qodef-mobile-header-opener" href="#">
	<span class="qodef-circles">
		<span class="qodef-circles-row qodef-cr-1">
			<span class="qodef-circle"></span>
			<span class="qodef-circle"></span>
			<span class="qodef-circle"></span>
		</span>
		<span class="qodef-circles-row qodef-cr-2">
			<span class="qodef-circle"></span>
			<span class="qodef-circle"></span>
			<span class="qodef-circle"></span>
		</span>
		<span class="qodef-circles-row qodef-cr-3">
			<span class="qodef-circle"></span>
			<span class="qodef-circle"></span>
			<span class="qodef-circle"></span>
		</span>
	</span>
</a>
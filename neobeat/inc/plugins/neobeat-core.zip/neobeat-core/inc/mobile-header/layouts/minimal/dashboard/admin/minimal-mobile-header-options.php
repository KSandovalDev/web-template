<?php

if ( ! function_exists( 'neobeat_core_add_minimal_mobile_header_options' ) ) {
	function neobeat_core_add_minimal_mobile_header_options( $page ) {
		
		$section = $page->add_section_element(
			array(
				'name'       => 'qodef_minimal_mobile_header_section',
				'title'      => esc_html__( 'Minimal Mobile Header', 'neobeat-core' ),
				'dependency' => array(
					'show' => array(
						'qodef_mobile_header_layout' => array(
							'values' => 'minimal',
							'default_value' => ''
						)
					)
				)
			)
		);
		
		$section->add_field_element(
			array(
				'field_type'  => 'text',
				'name'        => 'qodef_minimal_mobile_header_height',
				'title'       => esc_html__( 'Minimal Height', 'neobeat-core' ),
				'description' => esc_html__( 'Enter header height', 'neobeat-core' ),
				'args'        => array(
					'suffix' => esc_html__( 'px', 'neobeat-core' )
				)
			)
		);
		
		$section->add_field_element(
			array(
				'field_type'  => 'color',
				'name'        => 'qodef_minimal_mobile_header_background_color',
				'title'       => esc_html__( 'Header Background Color', 'neobeat-core' ),
				'description' => esc_html__( 'Enter header background color', 'neobeat-core' ),
				'args'        => array(
					'suffix' => esc_html__( 'px', 'neobeat-core' )
				)
			)
		);
	}
	
	add_action( 'neobeat_core_action_after_mobile_header_options_map', 'neobeat_core_add_minimal_mobile_header_options' );
}
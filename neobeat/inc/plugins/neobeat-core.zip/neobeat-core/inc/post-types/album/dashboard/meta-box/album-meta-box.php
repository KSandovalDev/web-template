<?php

if ( ! function_exists( 'neobeat_core_add_album_single_meta_box' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function neobeat_core_add_album_single_meta_box() {
		$qode_framework = qode_framework_get_framework_root();
		
		$page = $qode_framework->add_options_page(
			array(
				'scope'  => array( 'album' ),
				'type'   => 'meta',
				'slug'   => 'album',
				'title'  => esc_html__( 'Album', 'neobeat-core' ),
				'layout' => 'tabbed'
			)
		);
		
		if ( $page ) {
			
			/* General sections */
			
			$general_section = $page->add_tab_element(
				array(
					'name'        => 'tab-general',
					'title'       => esc_html__( 'General Settings', 'neobeat-core' ),
					'description' => esc_html__( 'General information about album single.', 'neobeat-core' )
				)
			);
			
			$general_section->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_album_single_layout',
					'title'       => esc_html__( 'Album Layout', 'neobeat-core' ),
					'description' => esc_html__( 'Choose layout for album single page', 'neobeat-core' ),
					'options'     => apply_filters( 'neobeat_core_filter_album_single_layout_options', array( '' => esc_html__( 'Default', 'neobeat-core' ) ) )
				)
			);
			
			$general_section->add_field_element(
				array(
					'field_type'  => 'date',
					'name'        => 'qodef_album_single_release_date',
					'title'       => esc_html__( 'Release Date', 'neobeat-core' ),
					'description' => esc_html__( 'Enter album release date', 'neobeat-core' ),
				)
			);
			
			$general_section->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_album_single_video_link',
					'title'       => esc_html__( 'Latest Video Link', 'neobeat-core' ),
					'description' => esc_html__( 'Enter video link', 'neobeat-core' ),
				)
			);
			
			$general_section->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_album_single_back_to_link',
					'title'       => esc_html__( '"Back To" Link', 'neobeat-core' ),
					'description' => esc_html__( 'Choose "Back To" page to link from album single', 'neobeat-core' ),
					'options'     => qode_framework_get_pages( true ),
				)
			);
			
			$info_items_repeater = $general_section->add_repeater_element(
				array(
					'name'        => 'qodef_album_single_info_items',
					'title'       => esc_html__( 'Info Items', 'neobeat-core' ),
					'description' => esc_html__( 'Enter additional info for album item', 'neobeat-core' ),
					'button_text' => esc_html__( 'Add New Info', 'neobeat-core' )
				)
			);
			
			$info_items_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_album_single_info_item_title',
					'title'      => esc_html__( 'Title', 'neobeat-core' )
				)
			);
			
			$info_items_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_album_single_info_item_text',
					'title'      => esc_html__( 'Text', 'neobeat-core' )
				)
			);
			
			$info_items_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_album_single_info_item_link',
					'title'      => esc_html__( 'Text Link', 'neobeat-core' )
				)
			);
			
			$general_section->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_masonry_image_dimension_album',
					'title'       => esc_html__( 'Image Dimension', 'neobeat-core' ),
					'description' => esc_html__( 'Choose an image layout for "masonry behavior" album list. If you are using fixed image proportions on the list, choose an option other than default', 'neobeat-core' ),
					'options'     => neobeat_core_get_select_type_options_pool( 'masonry_image_dimension' )
				)
			);
			
			/* Tracks sections */
			
			$tracks_section = $page->add_tab_element(
				array(
					'name'        => 'tab-tracks',
					'title'       => esc_html__( 'Tracks Settings', 'neobeat-core' ),
					'description' => esc_html__( 'Populate album single tracks information', 'neobeat-core' )
				)
			);
			
			$tracks_repeater = $tracks_section->add_repeater_element(
				array(
					'name'        => 'qodef_album_single_tracks',
					'title'       => esc_html__( 'Tracks', 'neobeat-core' ),
					'button_text' => esc_html__( 'Add New Track', 'neobeat-core' )
				)
			);
			
			$tracks_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_album_single_track_title',
					'title'      => esc_html__( 'Title', 'neobeat-core' )
				)
			);
			
			$tracks_repeater->add_field_element(
				array(
					'field_type' => 'file',
					'name'       => 'qodef_album_single_track_file',
					'title'      => esc_html__( 'Audio File (mp3)', 'neobeat-core' ),
					'args'       => array(
						'allowed_type' => '[audio/mpeg]'
					)
				)
			);
			
			$tracks_repeater->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_album_single_track_link_type',
					'title'         => esc_html__( 'Track Link Type', 'neobeat-core' ),
					'description'   => esc_html__( 'Choose a link type for album track', 'neobeat-core' ),
					'options'       => array(
						''              => esc_html__( 'Default', 'neobeat-core' ),
						'free-download' => esc_html__( 'Free Download', 'neobeat-core' ),
						'buy-track'     => esc_html__( 'Buy Track', 'neobeat-core' )
					),
					'default_value' => 'free-download'
				)
			);
			
			$tracks_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_album_single_track_buy_track_link',
					'title'      => esc_html__( 'Track Buy Link', 'neobeat-core' ),
					'dependency' => array(
						'show' => array(
							'qodef_album_single_track_link_type' => array(
								'values'        => 'buy-track',
								'default_value' => ''
							)
						)
					)
				)
			);
			
			$tracks_repeater->add_field_element(
				array(
					'field_type' => 'select',
					'name'       => 'qodef_album_single_track_buy_track_link_target',
					'title'      => esc_html__( 'Track Buy Link Target', 'neobeat-core' ),
					'options'    => neobeat_core_get_select_type_options_pool( 'link_target', false ),
					'dependency' => array(
						'show' => array(
							'qodef_album_single_track_link_type' => array(
								'values'        => 'buy-track',
								'default_value' => ''
							)
						)
					)
				)
			);
			
			$tracks_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_album_single_track_additional_info',
					'title'      => esc_html__( 'Additional Track Info', 'neobeat-core' )
				)
			);
			
			$tracks_repeater->add_field_element(
				array(
					'field_type' => 'textarea',
					'name'       => 'qodef_album_single_track_lyrics',
					'title'      => esc_html__( 'Lyrics', 'neobeat-core' )
				)
			);
			
			/* Stores sections */
			
			$stores_section = $page->add_tab_element(
				array(
					'name'        => 'tab-stores',
					'title'       => esc_html__( 'Stores Settings', 'neobeat-core' ),
					'description' => esc_html__( 'Set available stores for album.', 'neobeat-core' )
				)
			);
			
			$stores_repeater = $stores_section->add_repeater_element(
				array(
					'name'        => 'qodef_album_single_stores',
					'title'       => esc_html__( 'Stores', 'neobeat-core' ),
					'button_text' => esc_html__( 'Add New Item', 'neobeat-core' )
				)
			);
			
			$stores_repeater->add_field_element(
				array(
					'field_type' => 'select',
					'name'       => 'qodef_album_single_stores_name',
					'title'      => esc_html__( 'Store', 'neobeat-core' ),
					'options'    => array(
						'amazonmp3'   => esc_html__( 'AmazonMP3', 'neobeat-core' ),
						'bandcamp'    => esc_html__( 'Bandcamp', 'neobeat-core' ),
						'deezer'      => esc_html__( 'Deezer', 'neobeat-core' ),
						'google-play' => esc_html__( 'Google Play', 'neobeat-core' ),
						'itunes'      => esc_html__( 'iTunes', 'neobeat-core' ),
						'spotify'     => esc_html__( 'Spotify', 'neobeat-core' ),
						'soundcloud'  => esc_html__( 'Soundcloud', 'neobeat-core' ),
						'youtube'     => esc_html__( 'YouTube', 'neobeat-core' ),
					)
				)
			);
			
			$stores_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_album_single_stores_link',
					'title'      => esc_html__( 'Store Link', 'neobeat-core' )
				)
			);
			
			/* Reviews sections */
			
			$reviews_section = $page->add_tab_element(
				array(
					'name'  => 'tab-reviews',
					'title' => esc_html__( 'Reviews Settings', 'neobeat-core' )
				)
			);
			
			$reviews_section->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_album_single_reviews_background_image',
					'title'       => esc_html__( 'Reviews Background Image', 'neobeat-core' ),
					'description' => esc_html__( 'Enter reviews area background image', 'neobeat-core' )
				)
			);
			
			$reviews_repeater = $reviews_section->add_repeater_element(
				array(
					'name'        => 'qodef_album_single_reviews',
					'title'       => esc_html__( 'Reviews', 'neobeat-core' ),
					'description' => esc_html__( 'Populate album single reviews info', 'neobeat-core' ),
					'button_text' => esc_html__( 'Add New Review', 'neobeat-core' )
				)
			);
			
			$reviews_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_album_single_review_title',
					'title'      => esc_html__( 'Title', 'neobeat-core' )
				)
			);
			
			$reviews_repeater->add_field_element(
				array(
					'field_type' => 'textarea',
					'name'       => 'qodef_album_single_review_text',
					'title'      => esc_html__( 'Text', 'neobeat-core' )
				)
			);
			
			/* Social sections */
			
			$social_section = $page->add_tab_element(
				array(
					'name'        => 'tab-social',
					'title'       => esc_html__( 'Social Networks Settings', 'neobeat-core' ),
					'description' => esc_html__( 'Populate album single social networks info', 'neobeat-core' )
				)
			);
			
			$social_icons_repeater = $social_section->add_repeater_element(
				array(
					'name'        => 'qodef_album_single_social_icons',
					'title'       => esc_html__( 'Social Networks', 'neobeat-core' ),
					'button_text' => esc_html__( 'Add New Network', 'neobeat-core' )
				)
			);
			
			$social_icons_repeater->add_field_element(
				array(
					'field_type' => 'iconpack',
					'name'       => 'qodef_album_single_icon',
					'title'      => esc_html__( 'Icon', 'neobeat-core' )
				)
			);
			
			$social_icons_repeater->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_album_single_icon_link',
					'title'      => esc_html__( 'Icon Link', 'neobeat-core' )
				)
			);
			
			$social_icons_repeater->add_field_element(
				array(
					'field_type' => 'select',
					'name'       => 'qodef_album_single_icon_target',
					'title'      => esc_html__( 'Icon Target', 'neobeat-core' ),
					'options'    => neobeat_core_get_select_type_options_pool( 'link_target' )
				)
			);
			
			// Hook to include additional options after module options
			do_action( 'neobeat_core_action_after_album_single_meta_box_map', $page );
		}
	}
	
	add_action( 'neobeat_core_action_default_meta_boxes_init', 'neobeat_core_add_album_single_meta_box' );
}

if ( ! function_exists( 'neobeat_core_include_general_meta_boxes_for_album_single' ) ) {
	/**
	 * Function that add general meta box options for this module
	 */
	function neobeat_core_include_general_meta_boxes_for_album_single() {
		$callbacks = neobeat_core_general_meta_box_callbacks();
		
		if ( ! empty( $callbacks ) ) {
			foreach ( $callbacks as $module => $callback ) {
				
				if ( $module !== 'page-sidebar' ) {
					add_action( 'neobeat_core_action_after_album_single_meta_box_map', $callback );
				}
			}
		}
	}
	
	add_action( 'neobeat_core_action_default_meta_boxes_init', 'neobeat_core_include_general_meta_boxes_for_album_single', 8 ); // Permission 8 is set in order to load it before default meta box function
}
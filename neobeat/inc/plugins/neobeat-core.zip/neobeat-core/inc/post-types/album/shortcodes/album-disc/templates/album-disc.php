<div class="<?php echo esc_attr($holder_classes); ?>">
	<?php if ($link !== '')  { ?>
		<a class="qodef-m-link" itemprop="url" href="<?php echo esc_url($link); ?>" target="<?php echo esc_attr($link_target) ?>"></a>
	<?php } ?>
	<div class="qodef-m-inner">
		<?php if ( $case_image !== '' ) { ?>
			<div class="qodef-m-case">
				<?php echo $case_image; ?>
				<div class="qodef-m-case-shadow">
					<?php echo $case_image; ?>
				</div>
			</div>
		<?php } ?>
		<?php if ( $disc_image !== '' ) { ?>
			<div class="qodef-m-disc">
				<div class="qodef-m-disc-image" <?php qode_framework_inline_style( $disc_image); ?>></div>
			</div>
		<?php } ?>
	</div>
</div>

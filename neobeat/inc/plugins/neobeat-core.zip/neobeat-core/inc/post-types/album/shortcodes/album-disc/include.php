<?php

include_once NEOBEAT_CORE_CPT_PATH . '/album/shortcodes/album-disc/album-disc.php';

<?php

if ( ! function_exists( 'neobeat_core_add_album_options' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function neobeat_core_add_album_options() {
		$qode_framework = qode_framework_get_framework_root();

		$page = $qode_framework->add_options_page(
			array(
				'scope'       => NEOBEAT_CORE_OPTIONS_NAME,
				'type'        => 'admin',
				'slug'        => 'album',
				'layout'      => 'tabbed',
				'icon'        => 'fa fa-cog',
				'title'       => esc_html__( 'Album', 'neobeat-core' ),
				'description' => esc_html__( 'Global Album Options', 'neobeat-core' )
			)
		);

		if ( $page ) {

			$single_tab = $page->add_tab_element(
				array(
					'name'        => 'tab-single',
					'icon'        => 'fa fa-cog',
					'title'       => esc_html__( 'Single Settings', 'neobeat-core' ),
					'description' => esc_html__( 'Settings related to album single pages', 'neobeat-core' )
				)
			);

			$single_tab->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_album_single_layout',
					'title'         => esc_html__( 'Single Layout', 'neobeat-core' ),
					'description'   => esc_html__( 'Choose default layout for album single', 'neobeat-core' ),
					'default_value' => apply_filters( 'neobeat_core_filter_album_single_layout_default_value', '' ),
					'options'       => apply_filters( 'neobeat_core_filter_album_single_layout_options', array() )
				)
			);

			// Hook to include additional options after single module options
			do_action( 'neobeat_core_action_after_album_options_single', $single_tab );

			// Hook to include additional options after module options
			do_action( 'neobeat_core_action_after_album_options_map', $page );
		}
	}

	add_action( 'neobeat_core_action_default_options_init', 'neobeat_core_add_album_options', neobeat_core_get_admin_options_map_position( 'album' ) );
}
<?php

if ( ! function_exists( 'neobeat_core_add_tracks_list_variation_standard' ) ) {
	function neobeat_core_add_tracks_list_variation_standard( $variations ) {
		$variations['standard'] = esc_html__( 'Standard', 'neobeat-core' );
		
		return $variations;
	}
	
	add_filter( 'neobeat_core_filter_tracks_list_layouts', 'neobeat_core_add_tracks_list_variation_standard' );
}

<div class="qodef-m-player-holder">
	<?php neobeat_core_template_part( 'post-types/album', 'templates/parts/post-info/album-player', ''); ?>
</div>
(function ($) {
	"use strict";
	
	qodefCore.shortcodes.neobeat_core_album_player = {};
	qodefCore.shortcodes.neobeat_core_album_player_rev_slider = {};
	
	$(document).ready(function () {
		qodefAlbumPlayer.init();
	});
	
	$(document).on('neobeat_core_trigger_tracks_list_event', function (e, albumID, trackID, event) {
		qodefAlbumPlayer.triggerPlayerEvent(albumID, trackID, event);
	});
	
	var qodefAlbumPlayer = {
		players: [],
		init: function () {
			this.holder = $('.qodef-album-player');
			
			if (this.holder.length) {
				this.holder.each(function () {
					var $thisHolder = $(this);
					
					qodefAlbumPlayer.triggerPlayer($thisHolder);
				});
			}
		},
		triggerPlayer: function ($holder) {
			$holder.addClass('qodef--loading');
			
			$.ajax({
				type: "GET",
				url: qodefGlobal.vars.restUrl + qodefGlobal.vars.getAlbumSongRestRoute,
				data: {
					album_id: $holder.children('.qodef-m-album').data('album-id')
				},
				success: function (response) {
					if (response.status === 'success') {
						qodefAlbumPlayer.initPlayer($holder, response.data);
					} else {
						console.log(response.message);
					}
				},
				complete: function () {
					$holder.removeClass('qodef--loading');
				}
			});
		},
		initPlayer: function ($holder, data) {
			$holder.addClass('qodef--init');
			
			var $playerPlayList = new jPlayerPlaylist({
				jPlayer: '#' + $holder.children('.qodef-m-album').attr('id'),
				cssSelectorAncestor: '#' + $holder.children('.qodef-m-player').attr('id')
			}, data, {
				supplied: "mp3",
				wmode: "window",
				useStateClassSkin: true,
				autoBlur: false,
				smoothPlayBar: true,
				keyEnabled: true,
				ready: function () {
					qodefAlbumPlayer.setTrackDetails($playerPlayList, $holder);
					qodefCore.body.trigger('neobeat_core_trigger_album_player_event', [$playerPlayList, 'ready']);
				},
				pause: function () {
					qodefCore.body.trigger('neobeat_core_trigger_album_player_event', [$playerPlayList, 'pause']);
					$( ".qodef-album-player .qodef-m-album-image" ).removeClass( "qodef-disc-rotating" );
				},
				play: function () {
					qodefAlbumPlayer.setTrackDetails($playerPlayList, $holder);
					qodefCore.body.trigger('neobeat_core_trigger_album_player_event', [$playerPlayList, 'play']);
					
					$( ".qodef-album-player .qodef-m-album-image" ).addClass( "qodef-disc-rotating" );
				}
			});
			
			qodefAlbumPlayer.players.push($playerPlayList);
		},
		setTrackDetails: function ($playerPlayList, $holder) {
			var $title = $holder.find('.qodef-m-player-track-title');
			
			if ($title.length) {
				$title.html($playerPlayList.original[$playerPlayList.current].title);
			}
		},
		triggerPlayerEvent: function (albumID, trackID, event) {
			if (typeof qodefAlbumPlayer.players === 'object' && typeof albumID !== 'undefined' && typeof event !== 'undefined') {
				$.each(qodefAlbumPlayer.players, function (key, value) {
					if (value.cssSelector.jPlayer === ( '#' + 'qodef-m-album-' + albumID ) ) {
						switch (event) {
							case 'pause':
								value.pause(trackID);
								break;
							case 'play':
								value.play(trackID);
								break;
						}
					}
				});
			}
		}
	};
	
	qodefCore.shortcodes.neobeat_core_album_player.qodefAlbumPlayer = qodefAlbumPlayer;
	qodefCore.shortcodes.neobeat_core_album_player_rev_slider.qodefAlbumPlayer = qodefAlbumPlayer;
	
})(jQuery);
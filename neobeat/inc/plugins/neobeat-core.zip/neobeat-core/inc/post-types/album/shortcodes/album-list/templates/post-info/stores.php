<?php
$stores = get_post_meta( get_the_ID(), 'qodef_album_single_stores', true );

if ( ! empty( $stores ) ) { ?>
	<div class="qodef-e-stores">
		<div class="qodef-e-stores-items qodef-ei qodef-layout--button">
			<?php foreach ( $stores as $store ) {
				$store_name = $store['qodef_album_single_stores_name'];
				$store_link  = ! empty( $store['qodef_album_single_stores_link'] ) ? $store['qodef_album_single_stores_link'] : '#';
				?>
				<a class="qodef-ei-item <?php echo esc_attr( 'qodef-store--' . $store_name ); ?>" href="<?php echo esc_url( $store_link ); ?>" target="_blank" title="<?php echo ucwords( str_replace( '-', ' ', $store_name ) ); ?>">
					<?php neobeat_core_template_part( 'post-types/album', 'templates/parts/icons/' . $store_name, '', array( 'icon_class' => 'qodef-ei-item-icon' ) ); ?>
					<?php switch ( $store_name ) {
					case 'amazonmp3':
					$item_label = esc_html__( 'Amazon MP3', 'neobeat-core' );
					break;
					case 'itunes':
					$item_label = esc_html__( 'App Store', 'neobeat-core' );
					break;
					case 'soundcloud':
					$item_label = esc_html__( 'SoundCloud', 'neobeat-core' );
					break;
					case 'youtube':
					$item_label = esc_html__( 'YouTube', 'neobeat-core' );
					break;
					default:
					$item_label = ucwords( str_replace( '-', ' ', $store_name ) );
					break;
					}
					?>
					<h6 class="qodef-ei-item-label"><?php echo esc_html( $item_label ); ?></h6>
				</a>
			<?php } ?>
		</div>
	</div>
<?php } ?>
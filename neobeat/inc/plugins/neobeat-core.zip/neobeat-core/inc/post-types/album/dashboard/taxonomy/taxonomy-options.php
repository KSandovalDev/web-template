<?php

if ( ! function_exists( 'neobeat_core_add_album_artist_options' ) ) {
	function neobeat_core_add_album_artist_options() {
		$qode_framework = qode_framework_get_framework_root();
		
		$page = $qode_framework->add_options_page(
			array(
				'scope' => array( 'artist' ),
				'type'  => 'taxonomy',
				'slug'  => 'artist',
			)
		);
		
		if ( $page ) {
			$page->add_field_element(
				array(
					'field_type' => 'image',
					'name'       => 'qodef_album_artist_image',
					'title'      => esc_html__( 'Artist Image', 'neobeat-core' )
				)
			);
			
			$page->add_field_element(
				array(
					'field_type' => 'image',
					'name'       => 'qodef_album_artist_background_image',
					'title'      => esc_html__( 'Artist Background Image', 'neobeat-core' )
				)
			);
			
			$page->add_field_element(
				array(
					'field_type' => 'textarea',
					'name'       => 'qodef_album_artist_subtitle',
					'title'      => esc_html__( 'Artist Subtitle Text', 'neobeat-core' )
				)
			);
			
			$page->add_field_element(
				array(
					'field_type' => 'textarea',
					'name'       => 'qodef_album_artist_biography',
					'title'      => esc_html__( 'Artist Biography', 'neobeat-core' )
				)
			);
			
			$page->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_album_artist_video',
					'title'      => esc_html__( 'Artist Video URL', 'neobeat-core' )
				)
			);
			
			$page->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_album_artist_facebook_link',
					'title'      => esc_html__( 'Artist Facebook Link', 'neobeat-core' )
				)
			);
			
			$page->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_album_artist_twitter_link',
					'title'      => esc_html__( 'Artist Twitter Link', 'neobeat-core' )
				)
			);
			
			$page->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_album_artist_instagram_link',
					'title'      => esc_html__( 'Artist Instagram Link', 'neobeat-core' )
				)
			);
			
			$page->add_field_element(
				array(
					'field_type' => 'text',
					'name'       => 'qodef_album_artist_youtube_link',
					'title'      => esc_html__( 'Artist YouTube Link', 'neobeat-core' )
				)
			);
		}
	}
	
	add_action( 'neobeat_core_action_register_cpt_tax_fields', 'neobeat_core_add_album_artist_options' );
}
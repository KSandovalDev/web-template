(function ($) {
	"use strict";
	
	qodefCore.shortcodes.neobeat_core_album_player_slider = {};
	qodefCore.shortcodes.neobeat_core_album_player_slider.qodefSwiper = qodef.qodefSwiper;
	qodefCore.shortcodes.neobeat_core_album_player_slider.qodefAlbumPlayer = qodefCore.shortcodes.neobeat_core_album_player.qodefAlbumPlayer;
	
})(jQuery);
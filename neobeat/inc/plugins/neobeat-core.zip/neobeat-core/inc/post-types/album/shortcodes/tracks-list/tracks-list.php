<?php

if ( ! function_exists( 'neobeat_core_add_tracks_list_shortcode' ) ) {
	/**
	 * Function that isadding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function neobeat_core_add_tracks_list_shortcode( $shortcodes ) {
		$shortcodes[] = 'NeoBeatCoreTracksListShortcode';

		return $shortcodes;
	}

	add_filter( 'neobeat_core_filter_register_shortcodes', 'neobeat_core_add_tracks_list_shortcode' );
}

if ( class_exists( 'NeoBeatCoreShortcode' ) ) {
	class NeoBeatCoreTracksListShortcode extends NeoBeatCoreShortcode {

		public function __construct() {
			$this->set_layouts( apply_filters( 'neobeat_core_filter_tracks_list_layouts', array() ) );

			parent::__construct();
		}

		public function map_shortcode() {
			$this->set_shortcode_path( NEOBEAT_CORE_CPT_URL_PATH . '/album/shortcodes/tracks-list' );
			$this->set_base( 'neobeat_core_tracks_list' );
			$this->set_name( esc_html__( 'Tracks List', 'neobeat-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays tracks list of album', 'neobeat-core' ) );
			$this->set_category( esc_html__( 'NeoBeat Core', 'neobeat-core' ) );
			
			$this->set_scripts(
				array(
					'jplaylist' => array(
						'registered'	=> false,
						'url'			=> NEOBEAT_CORE_CPT_URL_PATH . '/album/shortcodes/album-player/assets/js/plugins/jplayer.playlist.min.js',
						'dependency'	=> array( 'jquery' )
					),
					'jplayer' => array(
						'registered'	=> false,
						'url'			=> NEOBEAT_CORE_CPT_URL_PATH . '/album/shortcodes/album-player/assets/js/plugins/jquery.jplayer.min.js',
						'dependency'	=> array( 'jquery' )
					)
				)
			);
			
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'custom_class',
				'title'      => esc_html__( 'Custom Class', 'neobeat-core' )
			) );

			$options_map = neobeat_core_get_variations_options_map( $this->get_layouts() );
			$this->set_option( array(
				'field_type'    => 'select',
				'name'          => 'layout',
				'title'         => esc_html__( 'Layout', 'neobeat-core' ),
				'options'       => $this->get_layouts(),
				'default_value' => $options_map['default_value'],
				'visibility'    => array( 'map_for_page_builder' => $options_map['visibility'] )
			) );
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'album',
				'title'      => esc_html__( 'Album', 'neobeat-core' ),
				'options'    => qode_framework_get_cpt_items( 'album' )
			) );
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'enable_artist_info',
				'title'      => esc_html__( 'Enable Artist Info', 'neobeat-core' ),
				'options'    => neobeat_core_get_select_type_options_pool( 'yes_no' ),
			) );
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'skin',
				'title'      => esc_html__( 'Skin', 'neobeat-core' ),
				'options'    => array(
					''      => esc_html__( 'Default', 'neobeat-core' ),
					'light' => esc_html__( 'Light', 'neobeat-core' )
				),
			) );
		}

		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'neobeat_core_tracks_list', $params );
			$html = str_replace( "\n", '', $html );

			return $html;
		}
		
		public function load_assets() {
			wp_enqueue_script( 'jplaylist' );
			wp_enqueue_script( 'jplayer' );
		}

		public function render( $options, $content = null ) {
			parent::render( $options );

			$atts = $this->get_atts();

			$atts['holder_classes'] = $this->get_holder_classes( $atts );

			return neobeat_core_get_template_part( 'post-types/album/shortcodes/tracks-list', 'variations/' . $atts['layout'] . '/templates/holder', '', $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-tracks-list';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-layout--' . $atts['layout'] : '';
			$holder_classes[] = ! empty( $atts['enable_artist_info'] ) && $atts['enable_artist_info'] === 'yes' ? 'qodef--has-artist' : '';
			$holder_classes[] = isset( $atts['skin'] ) && ! empty( $atts['skin'] ) ? 'qodef-skin--' . $atts['skin'] : '';

			return implode( ' ', $holder_classes );
		}
	}
}
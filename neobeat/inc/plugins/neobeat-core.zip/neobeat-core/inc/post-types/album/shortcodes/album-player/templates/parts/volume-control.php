<div class="qodef-m-volume-control jp-gui jp-interface">
	<div class="jp-volume-controls">
		<a class="jp-mute">
			<?php neobeat_core_template_part( 'post-types/album', 'templates/parts/icons/volume-icon', '', array( 'icon_class' => 'qodef-m-player-controls-icon' ) ); ?>
			<?php neobeat_core_template_part( 'post-types/album', 'templates/parts/icons/mute', '', array( 'icon_class' => 'qodef-m-player-controls-icon' ) ); ?>
		</a>
		<div class="jp-volume-bar">
			<div class="jp-volume-bar-value"></div>
		</div>
	</div>
</div>
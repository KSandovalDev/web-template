<div <?php qode_framework_class_attribute( $item_classes ); ?>>
	<div class="qodef-e-inner ">
		<div class="qodef-e-media-image-holder">
			<?php neobeat_core_list_sc_template_part( 'post-types/album/shortcodes/album-player-slider', 'post-info/image-background', '', $params ); ?>
			<div class="qodef-e-inner-info-holder">
				<?php neobeat_core_list_sc_template_part( 'post-types/album/shortcodes/album-player-slider', 'post-info/title', '', $params ); ?>
				<?php neobeat_core_list_sc_template_part( 'post-types/album/shortcodes/album-player-slider', 'post-info/artist', '', $params ); ?>
			</div>
			<?php neobeat_core_list_sc_template_part( 'post-types/album/shortcodes/album-player-slider', 'post-info/link', '', $params ); ?>
		</div>
		<?php neobeat_core_list_sc_template_part( 'post-types/album/shortcodes/album-player-slider', 'post-info/player', '', $params ); ?>
	</div>
</div>
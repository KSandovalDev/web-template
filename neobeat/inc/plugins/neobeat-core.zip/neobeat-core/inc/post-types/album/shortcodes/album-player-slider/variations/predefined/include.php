<?php

include_once NEOBEAT_CORE_CPT_PATH . '/album/shortcodes/album-player-slider/variations/predefined/predefined.php';
<div class="qodef-e-info-content">
	<<?php echo esc_attr( $title_tag ); ?> class="qodef-e-info-artist">
	<a itemprop="url" class="qodef-e-info-content-link" href="<?php echo esc_url( get_term_link( $term_id ) ); ?>">
		<?php echo esc_html( get_term_field( 'name', $term_id ) ); ?>
	</a>
</<?php echo esc_attr( $title_tag ); ?>>
</div>
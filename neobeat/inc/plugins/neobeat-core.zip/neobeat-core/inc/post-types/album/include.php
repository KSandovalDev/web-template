<?php

include_once NEOBEAT_CORE_CPT_PATH . '/album/helper.php';

foreach ( glob( NEOBEAT_CORE_CPT_PATH . '/album/dashboard/admin/*.php' ) as $module ) {
	include_once $module;
}

foreach ( glob( NEOBEAT_CORE_CPT_PATH . '/album/dashboard/meta-box/*.php' ) as $module ) {
	include_once $module;
}

foreach ( glob( NEOBEAT_CORE_CPT_PATH . '/album/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}

if ( ! function_exists( 'neobeat_core_include_album_tax_fields' ) ) {
	function neobeat_core_include_album_tax_fields() {
		include_once NEOBEAT_CORE_CPT_PATH . '/album/dashboard/taxonomy/taxonomy-options.php';
	}
	
	add_action( 'neobeat_core_action_include_cpt_tax_fields', 'neobeat_core_include_album_tax_fields' );
}
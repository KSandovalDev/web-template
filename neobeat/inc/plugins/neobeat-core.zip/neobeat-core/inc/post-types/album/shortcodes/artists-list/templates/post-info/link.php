<a class="qodef-e-link" itemprop="url" href="<?php echo esc_url( get_term_link( $term_id ) ); ?>"></a>

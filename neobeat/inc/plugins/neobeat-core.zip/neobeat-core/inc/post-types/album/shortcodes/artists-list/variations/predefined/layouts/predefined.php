<div <?php qode_framework_class_attribute( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<?php neobeat_core_list_sc_template_part( 'post-types/album/shortcodes/artists-list', 'post-info/image', '', $params ); ?>
		<?php neobeat_core_list_sc_template_part( 'post-types/album/shortcodes/artists-list', 'post-info/link', '', $params ); ?>
		<?php neobeat_core_list_sc_template_part( 'post-types/album/shortcodes/artists-list', 'post-info/artist', '', $params ); ?>
	</div>
</div>
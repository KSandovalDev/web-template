<div class="qodef-m-player-controls jp-gui jp-interface">
	<ul class="jp-controls">
		<li>
			<a class="jp-previous">
				<?php neobeat_core_template_part( 'post-types/album', 'templates/parts/icons/previous', '', array( 'icon_class' => 'qodef-m-player-controls-icon' ) ); ?>
			</a>
		</li>
		<li>
			<a class="jp-play">
				<?php neobeat_core_template_part( 'post-types/album', 'templates/parts/icons/play', '', array( 'icon_class' => 'qodef-m-player-controls-icon' ) ); ?>
				<?php neobeat_core_template_part( 'post-types/album', 'templates/parts/icons/pause', '', array( 'icon_class' => 'qodef-m-player-controls-icon' ) ); ?>
			</a>
		</li>
		<li>
			<a class="jp-next">
				<?php neobeat_core_template_part( 'post-types/album', 'templates/parts/icons/next', '', array( 'icon_class' => 'qodef-m-player-controls-icon' ) ); ?>
			</a>
		</li>
	</ul>
</div>
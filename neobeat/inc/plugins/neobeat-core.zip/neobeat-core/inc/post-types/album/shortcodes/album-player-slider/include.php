<?php

include_once NEOBEAT_CORE_CPT_PATH . '/album/shortcodes/album-player-slider/album-player-slider.php';

foreach ( glob( NEOBEAT_CORE_CPT_PATH . '/album/shortcodes/album-player-slider/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
<?php

if ( ! function_exists( 'neobeat_core_add_album_player_slider_shortcode' ) ) {
	/**
	 * Function that isadding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function neobeat_core_add_album_player_slider_shortcode( $shortcodes ) {
		$shortcodes[] = 'NeoBeatCoreAlbumPlayerSliderShortcode';
		
		return $shortcodes;
	}
	
	add_filter( 'neobeat_core_filter_register_shortcodes', 'neobeat_core_add_album_player_slider_shortcode' );
}

if ( class_exists( 'NeoBeatCoreListShortcode' ) ) {
	class NeoBeatCoreAlbumPlayerSliderShortcode extends NeoBeatCoreListShortcode {
		
		public function __construct() {
			$this->set_post_type( 'album' );
			$this->set_layouts( apply_filters( 'neobeat_core_filter_album_player_slider_layouts', array() ) );
			
			parent::__construct();
		}
		
		public function map_shortcode() {
			$this->set_shortcode_path( NEOBEAT_CORE_CPT_URL_PATH . '/album/shortcodes/album-player-slider' );
			$this->set_base( 'neobeat_core_album_player_slider' );
			$this->set_name( esc_html__( 'Album Player Slider', 'neobeat-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays list of album', 'neobeat-core' ) );
			$this->set_category( esc_html__( 'NeoBeat Core', 'neobeat-core' ) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'custom_class',
				'title'      => esc_html__( 'Custom Class', 'neobeat-core' )
			) );
			$this->set_scripts(
				array(
					'album-player-slider' => array(
						'registered'	=> false,
						'url'			=> NEOBEAT_CORE_CPT_URL_PATH . '/album/shortcodes/album-player-slider/variations/predefined/assets/js/plugins/d3.v5.min.js',
						'dependency'	=> array( 'jquery' )
					)
				)
			);
			$this->map_query_options( array( 'post_type' => $this->get_post_type() ) );
			$this->map_layout_options( array(
				'layouts'                 => $this->get_layouts(),
				'default_value_title_tag' => 'h2'
			));
			$this->map_list_options( array(
				'exclude_behavior' => array( 'behavior', 'columns', 'masonry' ),
				'exclude_option'   => array( 'images_proportion', 'space', 'columns' )
			));
		}
		
		public function load_assets() {
			wp_enqueue_script( 'album-player-slider' );
		}
		
		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'neobeat_core_album_player_slider', $params );
			$html = str_replace( "\n", '', $html );
			
			return $html;
		}
		
		public function render( $options, $content = null ) {
			parent::render( $options );
			
			$atts = $this->get_atts();
			
			// Predefined shortcode options
			$atts['behavior'] = 'slider';
			$atts['columns'] = 'auto';
			$atts['images_proportion'] = 'original';
			
			$atts['post_type'] = $this->get_post_type();
			
			// Additional query args
			$atts['additional_query_args'] = $this->get_additional_query_args( $atts );
			
			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['item_classes']   = $this->get_item_classes( $atts );
			$atts['query_result']   = new \WP_Query( neobeat_core_get_query_params( $atts ) );
			$atts['slider_attr']    = $this->get_slider_data( $atts, array(
				'centeredSlides' => true,
				'sliderScroll' => true,
			    'loopedSlides' => 10,
			) );
			$atts['this_shortcode'] = $this;
			
			return neobeat_core_get_template_part( 'post-types/album/shortcodes/album-player-slider', 'templates/content', $atts['behavior'], $atts );
		}
		
		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();
			
			$holder_classes[] = 'qodef-album-player-slider';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-layout--' . $atts['layout'] : '';
			
			$list_classes   = $this->get_list_classes( $atts );
			$holder_classes = array_merge( $holder_classes, $list_classes );
			
			return implode( ' ', $holder_classes );
		}
		
		public function get_item_classes( $atts ) {
			$item_classes = $this->init_item_classes();
			
			$list_item_classes   = $this->get_list_item_classes( $atts );
			
			$item_classes = array_merge( $item_classes, $list_item_classes );
			
			return implode( ' ', $item_classes );
		}
		
		public function get_title_styles( $atts ) {
			$styles = array();
			
			if ( ! empty( $atts['text_transform'] ) ) {
				$styles[] = 'text-transform: ' . $atts['text_transform'];
			}
			
			return $styles;
		}
	}
}
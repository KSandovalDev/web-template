<?php

if ( qode_framework_is_installed( 'revolution-slider' ) && qode_framework_is_installed( 'elementor' ) ) {
	include_once NEOBEAT_CORE_CPT_PATH . '/album/shortcodes/album-player-rev-slider/helper.php';
	include_once NEOBEAT_CORE_CPT_PATH . '/album/shortcodes/album-player-rev-slider/album-player-rev-slider.php';
}
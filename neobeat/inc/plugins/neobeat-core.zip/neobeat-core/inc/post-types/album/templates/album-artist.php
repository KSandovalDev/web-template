<?php
$queried_tax = get_queried_object();
$tax         = $queried_tax->taxonomy;
$tax_slug    = $queried_tax->slug;
$tax_id      = $queried_tax->term_id;

$params = array(
	'term_id' => $tax_id,
);
?>
<div class="qodef-grid-item <?php echo esc_attr( neobeat_core_get_page_content_sidebar_classes() ); ?>">
	<div class="qodef-artist-item qodef-m">
		<div class="qodef-m-inner">
			<div class="qodef-m-media">
				<?php neobeat_core_template_part( 'post-types/album', 'templates/artist/image', '', $params ); ?>
			</div>
			<div class="qodef-m-content">
				<?php neobeat_core_template_part( 'post-types/album', 'templates/artist/title', '', $params ); ?>
				<?php neobeat_core_template_part( 'post-types/album', 'templates/artist/subtitle', '', $params ); ?>
				<?php neobeat_core_template_part( 'post-types/album', 'templates/artist/biography', '', $params ); ?>
				<?php neobeat_core_template_part( 'post-types/album', 'templates/artist/social-networks', '', $params ); ?>
			</div>
		</div>
		<div class="qodef-m-albums">
			<h2 class="qodef-m-albums-title"><?php esc_html_e( 'The Latest Albums', 'neobeat-core' ); ?></h2>
			<p class="qodef-m-albums-description"><?php echo sprintf( esc_html__( 'Lorem ipsum dolor sit amet of Lorem Ipsum. Proin gravida %s lorem quis bibendum', 'neobeat-core' ), '<br />' ); ?></p>
			<?php
			$album_params = array(
				'columns'       => '3',
				'layout'        => 'gallery',
				'enable_stores' => 'yes',
			);
			
			neobeat_core_generate_album_archive_with_shortcode( $tax, $tax_slug, $album_params ); ?>
		</div>
		<?php neobeat_core_template_part( 'post-types/album', 'templates/artist/artist-video', '', $params ); ?>
	</div>
</div>
<div class="qodef-m-track-time jp-gui jp-interface">
	<span class="qodef-m-track-time-current jp-current-time"></span>/<span class="qodef-m-track-time-duration jp-duration"></span>
</div>
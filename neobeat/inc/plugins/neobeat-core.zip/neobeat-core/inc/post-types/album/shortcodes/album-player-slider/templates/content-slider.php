<div <?php qode_framework_class_attribute( $holder_classes ); ?> <?php qode_framework_inline_attr( $slider_attr, 'data-options' ); ?>>
	<div class="swiper-wrapper">
		<?php
		// Include items
		neobeat_core_template_part( 'post-types/album/shortcodes/album-player-slider', 'templates/loop', '', $params );
		?>
	</div>
	<?php if ( $slider_navigation !== 'no' ) { ?>
		<?php if ( $layout !== 'predefined' ) { ?>
			<div class="swiper-button-prev">
				<svg class="qodef-svg-circle"><circle cx="50%" cy="50%" r="45%"></circle></svg>
				<svg class="qodef-svg-circle"><circle cx="50%" cy="50%" r="45%"></circle></svg>
				<?php echo qode_framework_icons()->render_icon( 'ion-ios-arrow-back', 'ionicons')?>
			</div>
			<div class="swiper-button-next">
				<svg class="qodef-svg-circle"><circle cx="50%" cy="50%" r="45%"></circle></svg>
				<svg class="qodef-svg-circle"><circle cx="50%" cy="50%" r="45%"></circle></svg>
				<?php echo qode_framework_icons()->render_icon( 'ion-ios-arrow-forward', 'ionicons')?>
			</div>
		<?php } else {?>
			<div class="qodef-content-grid qodef-swiper-navigation-holder">
				<div class="swiper-button-prev">
					<?php echo qode_framework_icons()->render_icon( 'ion-ios-arrow-back', 'ionicons')?>
					<span class="qodef-swiper-button-nav-text"><?php echo esc_html__( 'Prev', 'neobeat-core' )?></span>
				</div>
				<div class="swiper-button-next">
					<span class="qodef-swiper-button-nav-text"><?php echo esc_html__( 'Next', 'neobeat-core' )?></span>
					<?php echo qode_framework_icons()->render_icon( 'ion-ios-arrow-forward', 'ionicons')?>
				</div>
			</div>
		<?php } ?>
	<?php } ?>
</div>
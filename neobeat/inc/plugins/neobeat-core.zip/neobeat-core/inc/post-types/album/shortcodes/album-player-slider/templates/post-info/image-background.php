<?php
$attachment_id = get_post_thumbnail_id();
$has_image     = has_post_thumbnail();

if ( $has_image ) {
	$image_dimension     = isset( $image_dimension ) && ! empty( $image_dimension ) ? esc_attr( $image_dimension['size'] ) : 'full';
	$image_url       = neobeat_core_get_list_shortcode_item_image_url( $image_dimension, $attachment_id );
	$style           = ! empty( $image_url ) ? 'background-image: url( ' . esc_url( $image_url ) . ')' : '';
	?>
	<div class="qodef-e-media-image qodef--background" <?php qode_framework_inline_style( $style ); ?>>
		<svg class='qodef--background-svg' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="1640" height="1500" xml:space="preserve">
			<defs>
				<linearGradient id="qodef-svg-gradient" gradientUnits="userSpaceOnUse" x1="3598.3691" y1="584.5073" x2="4162.3652" y2="584.5073" gradientTransform="matrix(0 -1 1 0 -298.6665 4166.6665)">
					<stop  offset="0" style="stop-color:#AD123C"/>
					<stop  offset="0.0211" style="stop-color:#C11841"/>
					<stop  offset="0.0453" style="stop-color:#CF1C44"/>
					<stop  offset="0.0747" style="stop-color:#D71E46"/>
					<stop  offset="0.1236" style="stop-color:#DA1F47"/>
					<stop  offset="0.1694" style="stop-color:#DC2D48"/>
					<stop  offset="0.27" style="stop-color:#E0454A"/>
					<stop  offset="0.3626" style="stop-color:#E2544B"/>
					<stop  offset="0.439" style="stop-color:#E3594B"/>
					<stop  offset="0.759" style="stop-color:#F1A479"/>
					<stop  offset="0.8573" style="stop-color:#F7C3A3"/>
					<stop  offset="0.9498" style="stop-color:#FCDBC5"/>
					<stop  offset="1" style="stop-color:#FEE4D2"/>
				</linearGradient>
			</defs>
		</svg>
	</div>
<?php } ?>
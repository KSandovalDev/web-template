<?php

if ( ! function_exists( 'neobeat_core_add_band_member_shortcode' ) ) {
	/**
	 * Function that isadding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function neobeat_core_add_band_member_shortcode( $shortcodes ) {
		$shortcodes[] = 'NeoBeatCoreBandMemberShortcode';
		
		return $shortcodes;
	}
	
	add_filter( 'neobeat_core_filter_register_shortcodes', 'neobeat_core_add_band_member_shortcode' );
}

if ( class_exists( 'NeoBeatCoreShortcode' ) ) {
	class NeoBeatCoreBandMemberShortcode extends NeoBeatCoreShortcode {
		
		public function map_shortcode() {
			$this->set_shortcode_path( NEOBEAT_CORE_CPT_URL_PATH . '/album/shortcodes/band-member' );
			$this->set_base( 'neobeat_core_band_member' );
			$this->set_name( esc_html__( 'Band Member', 'neobeat-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays band member element', 'neobeat-core' ) );
			$this->set_category( esc_html__( 'NeoBeat Core', 'neobeat-core' ) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'custom_class',
				'title'      => esc_html__( 'Custom Class', 'neobeat-core' )
			) );
			$this->set_option( array(
				'field_type' => 'image',
				'name'       => 'image',
				'title'      => esc_html__( 'Image', 'neobeat-core' ),
			) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'image_size',
				'title'      => esc_html__( 'Image Size', 'neobeat-core' ),
			) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'link',
				'title'      => esc_html__( 'Custom Link', 'neobeat-core' ),
			) );
			$this->set_option( array(
				'field_type'    => 'select',
				'name'          => 'target',
				'title'         => esc_html__( 'Custom Link Target', 'neobeat-core' ),
				'options'       => neobeat_core_get_select_type_options_pool( 'link_target' ),
				'default_value' => '_self',
			) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'title',
				'title'      => esc_html__( 'Title', 'neobeat-core' ),
			) );
			$this->set_option( array(
				'field_type'    => 'select',
				'name'          => 'title_tag',
				'title'         => esc_html__( 'Title Tag', 'neobeat-core' ),
				'options'       => neobeat_core_get_select_type_options_pool( 'title_tag' ),
				'default_value' => 'h2',
			) );
			$this->set_option( array(
				'field_type' => 'color',
				'name'       => 'title_color',
				'title'      => esc_html__( 'Title Color', 'neobeat-core' ),
			) );
			$this->set_option( array(
				'field_type' => 'textarea',
				'name'       => 'text',
				'title'      => esc_html__( 'Text', 'neobeat-core' ),
			) );
			$this->set_option( array(
				'field_type' => 'color',
				'name'       => 'text_color',
				'title'      => esc_html__( 'Text Color', 'neobeat-core' ),
			) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'text_margin_top',
				'title'      => esc_html__( 'Text Margin Top', 'neobeat-core' ),
			) );
			
			for ( $i = 1; $i <= 4; $i ++ ) {
				$this->set_option( array(
					'field_type' => 'iconpack',
					'name'       => 'main_icon_' . $i,
					'title'      => sprintf( esc_html__( 'Icon %s', 'neobeat-core' ), $i ),
					'group'      => esc_html__( 'Social Icons', 'neobeat-core' ),
				) );
				$this->set_option( array(
					'field_type' => 'color',
					'name'       => 'icon_color_' . $i,
					'title'      => sprintf( esc_html__( 'Icon Color', 'neobeat-core' ), $i ),
					'group'      => esc_html__( 'Social Icons', 'neobeat-core' ),
				) );
				$this->set_option( array(
					'field_type' => 'color',
					'name'       => 'icon_hover_color_' . $i,
					'title'      => sprintf( esc_html__( 'Icon Hover Color', 'neobeat-core' ), $i ),
					'group'      => esc_html__( 'Social Icons', 'neobeat-core' ),
				) );
				$this->set_option( array(
					'field_type' => 'text',
					'name'       => 'icon_link_' . $i,
					'title'      => sprintf( esc_html__( 'Icon Link', 'neobeat-core' ), $i ),
					'group'      => esc_html__( 'Social Icons', 'neobeat-core' ),
				) );
				$this->set_option( array(
					'field_type'    => 'select',
					'name'          => 'icon_target_' . $i,
					'title'         => sprintf( esc_html__( 'Link Target', 'neobeat-core' ), $i ),
					'options'       => neobeat_core_get_select_type_options_pool( 'link_target' ),
					'default_value' => '_self',
					'group'      => esc_html__( 'Social Icons', 'neobeat-core' ),
				) );
			}
			
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'content_alignment',
				'title'      => esc_html__( 'Content Alignment', 'neobeat-core' ),
				'options'    => array(
					''      => esc_html__( 'Default', 'neobeat-core' ),
					'left'  => esc_html__( 'Left', 'neobeat-core' ),
				),
			) );
		}
		
		public function render( $options, $content = null ) {
			parent::render( $options );
			
			$atts = $this->get_atts();
			
			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['title_styles']   = $this->get_title_styles( $atts );
			$atts['text_styles']    = $this->get_text_styles( $atts );
			$atts['image_params']   = $this->generate_image_params( $atts );
			
			return neobeat_core_get_template_part( 'post-types/album/shortcodes/band-member', 'templates/holder', '', $atts );
		}
		
		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();
			
			$holder_classes[] = 'qodef-band-member';
			$holder_classes[] = ! empty( $atts['content_alignment'] ) ? 'qodef-content--' . esc_attr( $atts['content_alignment'] ) : '';
			
			return implode( ' ', $holder_classes );
		}
		
		private function get_title_styles( $atts ) {
			$styles = array();
			
			if ( ! empty( $atts['title_color'] ) ) {
				$styles[] = 'color: ' . $atts['title_color'];
			}
			
			return $styles;
		}
		
		private function get_text_styles( $atts ) {
			$styles = array();
			
			if ( $atts['text_margin_top'] !== '' ) {
				if ( qode_framework_string_ends_with_space_units( $atts['text_margin_top'] ) ) {
					$styles[] = 'margin-top: ' . $atts['text_margin_top'];
				} else {
					$styles[] = 'margin-top: ' . intval( $atts['text_margin_top'] ) . 'px';
				}
			}
			
			if ( ! empty( $atts['text_color'] ) ) {
				$styles[] = 'color: ' . $atts['text_color'];
			}
			
			return $styles;
		}
		
		private function generate_image_params( $atts ) {
			$image = array();
			
			if ( ! empty( $atts['image'] ) ) {
				$id = $atts['image'];
				
				$image['image_id'] = intval( $id );
				$image_original    = wp_get_attachment_image_src( $id, 'full' );
				$image['url']      = $image_original[0];
				$image['alt']      = get_post_meta( $id, '_wp_attachment_image_alt', true );
				
				$image_size = trim( $atts['image_size'] );
				preg_match_all( '/\d+/', $image_size, $matches ); /* check if numeral width and height are entered */
				if ( in_array( $image_size, array( 'thumbnail', 'thumb', 'medium', 'large', 'full' ) ) ) {
					$image['image_size'] = $image_size;
				} elseif ( ! empty( $matches[0] ) ) {
					$image['image_size'] = array(
						$matches[0][0],
						$matches[0][1]
					);
				} else {
					$image['image_size'] = 'full';
				}
			}
			
			return $image;
		}
	}
}
<?php

if ( ! function_exists( 'neobeat_core_add_album_list_variation_gallery' ) ) {
	function neobeat_core_add_album_list_variation_gallery( $variations ) {
		$variations['gallery'] = esc_html__( 'Gallery', 'neobeat-core' );
		
		return $variations;
	}
	
	add_filter( 'neobeat_core_filter_album_list_layouts', 'neobeat_core_add_album_list_variation_gallery' );
}

if ( ! function_exists( 'neobeat_core_add_album_list_options_gallery' ) ) {
	function neobeat_core_add_album_list_options_gallery( $options ) {
		$gallery_options   = array();
		$store_option      = array(
			'field_type' => 'select',
			'name'       => 'enable_stores',
			'title'      => esc_html__( 'Enable Stores Buttons', 'neobeat-core' ),
			'dependency' => array(
				'show' => array(
					'behavior' => array(
						'values'        => 'columns',
						'default_value' => 'default'
					)
				),
			),
			'options'    => neobeat_core_get_select_type_options_pool( 'yes_no', false ),
			'group'      => esc_html__( 'Layout', 'neobeat-core' )
		);
		$gallery_options[] = $store_option;
		
		return array_merge( $options, $gallery_options );
	}
	
	add_filter( 'neobeat_core_filter_album_list_extra_options', 'neobeat_core_add_album_list_options_gallery' );
}
<?php

if ( ! function_exists( 'neobeat_core_register_albums_for_meta_options' ) ) {
	function neobeat_core_register_albums_for_meta_options( $post_types ) {
		$post_types[] = 'album';
		
		return $post_types;
	}
	
	add_filter( 'qode_framework_filter_meta_box_save', 'neobeat_core_register_albums_for_meta_options' );
	add_filter( 'qode_framework_filter_meta_box_remove', 'neobeat_core_register_albums_for_meta_options' );
}

if ( ! function_exists( 'neobeat_core_add_albums_custom_post_type' ) ) {
	/**
	 * Function that adds custom post type
	 *
	 * @param $cpts array
	 *
	 * @return array
	 */
	function neobeat_core_add_albums_custom_post_type( $cpts ) {
		$cpts[] = 'NeoBeatCoreAlbumCPT';
		
		return $cpts;
	}
	
	add_filter( 'neobeat_core_filter_register_custom_post_types', 'neobeat_core_add_albums_custom_post_type' );
}

if ( class_exists( 'QodeFrameworkCustomPostType' ) ) {
	class NeoBeatCoreAlbumCPT extends QodeFrameworkCustomPostType {
		
		public function map_post_type() {
			$name = esc_html__( 'Album', 'neobeat-core' );
			$this->set_base( 'album' );
			$this->set_menu_position( 15 );
			$this->set_menu_icon( 'dashicons-format-audio' );
			$this->set_slug( 'album' );
			$this->set_name( $name );
			$this->set_path( NEOBEAT_CORE_CPT_PATH . '/album' );
			$this->set_labels( array(
				'name'          => esc_html__( 'NeoBeat Album', 'neobeat-core' ),
				'singular_name' => esc_html__( 'Album', 'neobeat-core' ),
				'add_item'      => esc_html__( 'New Album', 'neobeat-core' ),
				'add_new_item'  => esc_html__( 'Add New Album', 'neobeat-core' ),
				'edit_item'     => esc_html__( 'Edit Album', 'neobeat-core' )
			) );
			$this->set_supports( array(
				'title',
				'thumbnail',
				'editor',
				'excerpt',
				'page-attributes'
			) );
			$this->add_post_taxonomy( array(
				'base'          => 'genre',
				'slug'          => 'genre',
				'singular_name' => esc_html__( 'Genre', 'neobeat-core' ),
				'plural_name'   => esc_html__( 'Genres', 'neobeat-core' ),
			) );
			$this->add_post_taxonomy( array(
				'base'          => 'album-label',
				'slug'          => 'album-label',
				'singular_name' => esc_html__( 'Label', 'neobeat-core' ),
				'plural_name'   => esc_html__( 'Labels', 'neobeat-core' ),
			) );
			$this->add_post_taxonomy( array(
				'base'          => 'artist',
				'slug'          => 'artist',
				'singular_name' => esc_html__( 'Artist', 'neobeat-core' ),
				'plural_name'   => esc_html__( 'Artists', 'neobeat-core' ),
			) );
		}
	}
}
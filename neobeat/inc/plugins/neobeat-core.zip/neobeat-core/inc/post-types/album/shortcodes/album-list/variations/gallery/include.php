<?php

include_once NEOBEAT_CORE_CPT_PATH . '/album/shortcodes/album-list/variations/gallery/gallery.php';
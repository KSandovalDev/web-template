<?php

if ( ! function_exists( 'neobeat_core_add_album_disc_shortcode' ) ) {
	/**
	 * Function that isadding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function neobeat_core_add_album_disc_shortcode( $shortcodes ) {
		$shortcodes[] = 'NeoBeatCoreAlbumDiscShortcode';
		
		return $shortcodes;
	}
	
	add_filter( 'neobeat_core_filter_register_shortcodes', 'neobeat_core_add_album_disc_shortcode' );
}

if ( class_exists( 'NeoBeatCoreShortcode' ) ) {
	class NeoBeatCoreAlbumDiscShortcode extends NeoBeatCoreShortcode {
		
		public function map_shortcode() {
			$this->set_shortcode_path( NEOBEAT_CORE_CPT_URL_PATH . '/album/shortcodes/album-disc' );
			$this->set_base( 'neobeat_core_album_disc' );
			$this->set_name( esc_html__( 'Album Disc', 'neobeat-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays album, disc image', 'neobeat-core' ) );
			$this->set_category( esc_html__( 'NeoBeat Core', 'neobeat-core' ) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'custom_class',
				'title'      => esc_html__( 'Custom Class', 'neobeat-core' )
			) );
			$this->set_option( array(
				'field_type' => 'image',
				'name'       => 'cd_case_image',
				'title'      => esc_html__( 'CD Case Image', 'neobeat-core' ),
			) );
			$this->set_option( array(
				'field_type' => 'image',
				'name'       => 'cd_image',
				'title'      => esc_html__( 'CD Image', 'neobeat-core' ),
			) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'image_size',
				'title'      => esc_html__( 'Image Size', 'neobeat-core' ),
			) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'link',
				'title'      => esc_html__( 'Image Link', 'neobeat-core' )
			) );
			$this->set_option( array(
				'field_type'    => 'select',
				'name'          => 'link_target',
				'title'         => esc_html__( 'Link Target', 'neobeat-core' ),
				'options'       => neobeat_core_get_select_type_options_pool( 'link_target' ),
				'default_value' => '_self'
			) );
		}
		
		public function render( $options, $content = null ) {
			parent::render( $options );
			
			$atts = $this->get_atts();
			
			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['case_image'] = $this->get_case_image( $atts );
			$atts['disc_image'] = $this->get_disc_image( $atts );
			
			return neobeat_core_get_template_part( 'post-types/album/shortcodes/album-disc', 'templates/album-disc', '', $atts );
		}
		
		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();
			
			$holder_classes[] = 'qodef-album-disc';
			
			return implode( ' ', $holder_classes );
		}
		
		public function get_case_image( $atts ) {
			$image = '';
			
			if ( ! empty( $atts['cd_case_image'] ) ) {
				$image_id = $atts['cd_case_image'];
				$image = neobeat_core_get_list_shortcode_item_image( 'full', $image_id );
			}
			
			return $image;
		}
		
		public function get_disc_image( $atts ) {
			$styles = array();
			
			if ( ! empty( $atts['cd_image'] ) ) {
				$styles[] = 'background-image: url(' . esc_url( wp_get_attachment_url( $atts['cd_image'] ) ) . ')';
			}
			
			return $styles;
		}
	}
}
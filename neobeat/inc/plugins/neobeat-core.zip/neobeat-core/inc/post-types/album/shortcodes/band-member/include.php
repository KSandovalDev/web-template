<?php

include_once NEOBEAT_CORE_CPT_PATH . '/album/shortcodes/band-member/band-member.php';

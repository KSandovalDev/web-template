<div class="<?php echo esc_attr($holder_classes); ?>">
	<div class="qodef-m-image">
		<?php if ( ! empty( $link ) ) { ?>
			<a itemprop="url" href="<?php echo esc_url( $link ); ?>" target="<?php echo esc_attr( $target ); ?>">
		<?php } ?>
			<?php if ( is_array( $image_params['image_size'] ) && count( $image_params['image_size'] ) ) {
				echo qode_framework_generate_thumbnail( $image_params['image_id'], $image_params['image_size'][0], $image_params['image_size'][1] );
			} else {
				echo wp_get_attachment_image( $image_params['image_id'], $image_params['image_size'] );
			} ?>
		<?php if ( ! empty( $link ) ) { ?>
			</a>
		<?php } ?>
	</div>
	<div class="qodef-m-content">
		<?php if ( ! empty( $title ) ) { ?>
			<<?php echo esc_attr( $title_tag ); ?> class="qodef-m-title" <?php qode_framework_inline_style( $title_styles ); ?>><?php echo esc_html( $title ); ?></<?php echo esc_attr( $title_tag ); ?>>
		<?php } ?>
		<?php if ( ! empty( $text ) ) { ?>
			<p class="qodef-m-text" <?php qode_framework_inline_style( $text_styles ); ?>><?php echo esc_html( $text ); ?></p>
		<?php } ?>
		<div class="qodef-m-social-icons">
			<?php for ( $i = 1; $i <= 4; $i ++ ) {
				$icon_pack = 'main_icon_' . $i;
	
				if ( ! empty( $$icon_pack ) ) {
					$icon             = 'main_icon_' . $i . '_' . str_replace( '-', '_', $$icon_pack );
					$icon_option      = 'main_icon_' . str_replace( '-', '_', $$icon_pack );
					$icon_color       = 'icon_color_' . $i;
					$icon_hover_color = 'icon_hover_color_' . $i;
					$icon_link        = 'icon_link_' . $i;
					$icon_target      = 'icon_target_' . $i;
					
					$icon_params = array(
						'main_icon'    => $$icon_pack,
						$icon_option   => $$icon,
						'custom_size'  => '18',
						'color'        => $$icon_color,
						'hover_color'  => $$icon_hover_color,
						'circle_hover' => 'yes',
						'link'         => $$icon_link,
						'target'       => $$icon_target,
					);
					echo NeoBeatCoreIconShortcode::call_shortcode( $icon_params );
				}
			} ?>
		</div>
	</div>
</div>
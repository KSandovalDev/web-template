<?php if ( isset( $enable_artist_info ) && $enable_artist_info === 'yes' ) {
	$term_values = get_the_terms( $album, 'artist' );
	
	if ( ! empty( $term_values ) ) {
		$current_artist     = $term_values[0];
		$artist_id          = $current_artist->term_id;
		$artist_image_meta  = get_term_meta( $artist_id, 'qodef_album_artist_image', true );
		$artist_image       = ! empty( $artist_image_meta ) ? $artist_image_meta : '';
		$artist_name        = $current_artist->name;
		$artist_description = $current_artist->description;
		
		$artist_holder_styles         = array();
		$artist_background_image_meta = get_term_meta( $artist_id, 'qodef_album_artist_background_image', true );
		
		if ( ! empty( $artist_background_image_meta ) ) {
			$artist_holder_styles[] = 'background-image: url( ' . wp_get_attachment_image_url( intval( $artist_background_image_meta ), 'full' ) . ')';
		}
		?>
		<div class="qodef-m-artist" <?php qode_framework_inline_style( $artist_holder_styles ); ?>>
			<?php if ( ! empty( $artist_image ) ) {
				echo wp_get_attachment_image( $artist_image, 'full', false, array( 'class' => 'qodef-m-artist-image' ) );
			} ?>
			<div class="qodef-m-artist-content">
				<h4 itemprop="author" class="qodef-m-artist-content-name"><?php echo esc_html( $artist_name ); ?></h4>
				<?php if ( ! empty( $artist_description ) ) { ?>
					<p class="qodef-m-artist-content-description"><?php echo esc_html( $artist_description ); ?></p>
				<?php } ?>
			</div>
		</div>
	<?php } ?>
<?php } ?>
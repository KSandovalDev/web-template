<?php

if ( ! function_exists( 'neobeat_core_get_album_revolution_sliders_array' ) ) {
	function neobeat_core_get_album_revolution_sliders_array() {
		$sliders = array();
		
		if ( class_exists( 'RevSliderSlider' ) ) {
			$slider         = new RevSliderSlider();
			$slider_objects = $slider->get_sliders();
			
			if ( ! empty( $slider_objects ) ) {
				foreach ( $slider_objects as $slider_object ) {
					$sliders[ $slider_object->alias ] = $slider_object->title;
				}
			}
		}
		
		return $sliders;
	}
}

if ( ! function_exists( 'neobeat_core_add_rest_api_album_player_global_variables' ) ) {
	function neobeat_core_add_rest_api_album_player_global_variables( $global, $namespace ) {
		$global['getAlbumSongRestRoute'] = $namespace . '/get-album-song';
		
		return $global;
	}
	
	add_filter( 'neobeat_filter_rest_api_global_variables', 'neobeat_core_add_rest_api_album_player_global_variables', 10, 2 );
}

if ( ! function_exists( 'neobeat_core_add_rest_api_album_player_route' ) ) {
	function neobeat_core_add_rest_api_album_player_route( $routes ) {
		$routes['get-album-song'] = array(
			'route'    => 'get-album-song',
			'methods'  => WP_REST_Server::READABLE,
			'callback' => 'neobeat_core_get_new_album_song',
			'args'     => array(
				'album_id' => array(
					'required'          => true,
					'validate_callback' => function($param, $request, $key) {
						return is_numeric( $param );
					},
					'description'       => esc_html__( 'Album ID data is integer parameter value', 'neobeat-core' )
				)
			)
		);
		
		return $routes;
	}
	
	add_filter( 'neobeat_filter_rest_api_routes', 'neobeat_core_add_rest_api_album_player_route' );
}

if ( ! function_exists( 'neobeat_core_get_new_album_song' ) ) {
	/**
	 * Function that load new album player song
	 *
	 * @return void
	 */
	function neobeat_core_get_new_album_song() {
		
		if ( ! isset( $_GET ) || empty( $_GET ) ) {
			qode_framework_get_ajax_status( 'error', esc_attr__( 'Get method is invalid', 'neobeat-core' ) );
		} else {
			$album_id = isset( $_GET['album_id'] ) ? intval( $_GET['album_id'] ) : 0;
			
			if ( ! empty( $album_id ) ) {
				$data    = array();
				$tracks  = get_post_meta( $album_id, 'qodef_album_single_tracks', true );
				
				if ( ! empty( $tracks ) ) {
					foreach ( $tracks as $key => $track ) {
						$data[ $key ]['album_name'] = get_the_title( $album_id );
						$data[ $key ]['unique_id']  = $track['qodef_album_single_track_file'];
						$data[ $key ]['title']      = $track['qodef_album_single_track_title'];
						$data[ $key ]['mp3']        = wp_get_attachment_url( $track['qodef_album_single_track_file'] );
					}
					
					qode_framework_get_ajax_status( 'success', esc_attr__( 'Song is loaded', 'neobeat-core' ), $data );
				} else {
					qode_framework_get_ajax_status( 'error', esc_attr__( 'Song is invalid', 'neobeat-core' ), $data );
				}
			} else {
				qode_framework_get_ajax_status( 'error', esc_attr__( 'Album ID is invalid', 'neobeat-core' ) );
			}
		}
	}
}
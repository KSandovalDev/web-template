<?php

include_once NEOBEAT_CORE_CPT_PATH . '/album/shortcodes/album-list/album-list.php';

foreach ( glob( NEOBEAT_CORE_CPT_PATH . '/album/shortcodes/album-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
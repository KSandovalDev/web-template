<?php

if ( ! function_exists( 'neobeat_core_add_artists_list_variation_predefined' ) ) {
	function neobeat_core_add_artists_list_variation_predefined( $variations ) {
		$variations['predefined'] = esc_html__( 'Predefined', 'neobeat-core' );
		
		return $variations;
	}
	
	add_filter( 'neobeat_core_filter_artists_list_layouts', 'neobeat_core_add_artists_list_variation_predefined' );
}

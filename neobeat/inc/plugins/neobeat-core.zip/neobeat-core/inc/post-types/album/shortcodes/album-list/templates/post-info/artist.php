<?php
$term_values = get_the_terms( get_the_ID(), 'artist' );

if ( ! empty( $term_values ) && ! is_wp_error( $term_values ) ) { ?>
	<span class="qodef-e-info-content"><?php
		foreach ( $term_values as $term_value ) { ?>
			<a itemprop="url" class="qodef-e-info-content-link" href="<?php echo esc_url( get_term_link( $term_value->term_id ) ); ?>"><?php echo esc_html( $term_value->name ); ?></a>
		<?php }
	?></span>
<?php }
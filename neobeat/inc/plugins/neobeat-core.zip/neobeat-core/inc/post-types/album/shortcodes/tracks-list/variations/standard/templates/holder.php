<?php
$tracks = get_post_meta( $album, 'qodef_album_single_tracks', true );

if ( ! empty( $tracks ) ) { ?>
	<div <?php qode_framework_class_attribute( $holder_classes ); ?> data-album-id="<?php echo esc_attr( $album ); ?>">
		<div id="qodef-m-track-player-<?php echo esc_attr( $album ); ?>" class="qodef-m-track-player"></div>
		<?php neobeat_core_template_part( 'post-types/album/shortcodes/tracks-list', '/templates/parts/artist', '', $params ); ?>
		<?php neobeat_core_template_part( 'post-types/album/shortcodes/tracks-list', '/templates/parts/tracks', '', array( 'album' => $album, 'tracks' => $tracks ) ); ?>
	</div>
<?php } ?>
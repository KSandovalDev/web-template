<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<div id="qodef-m-album-<?php echo intval( $album ); ?>" class="qodef-m-album jp-jplayer" data-album-id="<?php echo intval( $album ); ?>"></div>
	<?php neobeat_core_template_part( 'post-types/album/shortcodes/album-player', '/templates/parts/album-image', '', $params ); ?>
	<div id="qodef-m-player-<?php echo intval( $album ); ?>" class="qodef-m-player">
		<div class="qodef-m-player-heading">
			<?php neobeat_core_template_part( 'post-types/album/shortcodes/album-player', '/templates/parts/track-title' ); ?>
			<?php neobeat_core_template_part( 'post-types/album/shortcodes/album-player', '/templates/parts/controls' ); ?>
		</div>
		<?php neobeat_core_template_part( 'post-types/album/shortcodes/album-player', '/templates/parts/progress' ); ?>
		<div class="qodef-m-player-footer">
			<?php neobeat_core_template_part( 'post-types/album/shortcodes/album-player', '/templates/parts/album-title', '', $params ); ?>
			<?php neobeat_core_template_part( 'post-types/album/shortcodes/album-player', '/templates/parts/track-duration' ); ?>
		</div>
		<?php neobeat_core_template_part( 'post-types/album/shortcodes/album-player', '/templates/parts/playlist' ); ?>
	</div>
</div>
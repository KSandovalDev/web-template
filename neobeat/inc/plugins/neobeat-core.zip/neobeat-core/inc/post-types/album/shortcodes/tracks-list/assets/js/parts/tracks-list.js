(function ($) {
	"use strict";
	
	qodefCore.shortcodes.neobeat_core_tracks_list = {};
	
	$(document).ready(function () {
		qodefTracksList.init();
	});
	
	$(document).on('neobeat_core_trigger_album_player_event', function (e, $playerPlayList, event) {
		qodefTracksList.initTriggered($playerPlayList, event);
	});
	
	var qodefTracksList = {
		init: function () {
			this.holder = $('.qodef-tracks-list');
			
			if (this.holder.length) {
				this.holder.each(function () {
					var $thisHolder = $(this);
					
					if (!qodefCore.body.hasClass('single-album')) {
						qodefTracksList.triggerPlayer($thisHolder);
					} else {
						qodefTracksList.triggerTrackClick($thisHolder);
					}
				});
			}
		},
		triggerPlayer: function ($holder) {
			$.ajax({
				type: "GET",
				url: qodefGlobal.vars.restUrl + qodefGlobal.vars.getAlbumSongRestRoute,
				data: {
					album_id: $holder.data('album-id'),
				},
				success: function (response) {
					if (response.status === 'success') {
						qodefTracksList.initPlayer($holder, response.data);
					} else {
						console.log(response.message);
					}
				}
			});
		},
		initPlayer: function ($holder, data) {
			var $playerPlayList = new jPlayerPlaylist({
				jPlayer: '#' + $holder.children('.qodef-m-track-player').attr('id'),
				cssSelectorAncestor: '#' + $holder.children('.qodef-m-track-player').attr('id'),
			}, data, {
				supplied: "mp3",
				wmode: "window",
				useStateClassSkin: true,
				autoBlur: false,
				smoothPlayBar: true,
				ready: function () {
					qodefTracksList.triggerTrackClick($holder, $playerPlayList);
				},
				pause: function () {
					qodefTracksList.initTriggered($playerPlayList, 'pause');
				},
				play: function () {
					qodefTracksList.initTriggered($playerPlayList, 'play');
				}
			});
		},
		initTriggered: function ($playerPlayList, event) {
			this.holder = $('.qodef-tracks-list');
			
			if (this.holder.length) {
				this.holder.each(function () {
					var $thisHolder = $(this);
					
					if (typeof event !== 'undefined') {
						switch (event) {
							case 'pause':
								qodefTracksList.setActiveTrack($thisHolder, $playerPlayList, event);
								break;
							case 'play':
								qodefTracksList.setActiveTrack($thisHolder, $playerPlayList, event);
								break;
						}
					}
				});
			}
		},
		triggerTrackClick: function($holder, $playerPlayList) {
			$holder.find('.qodef-e-heading-title, .qodef-e-action-control.qodef--play').on('click', function (e) {
				e.preventDefault();
				
				var $currentTrack = $(this).parents('.qodef-m-tracks-list-item');
			
				if ($currentTrack.hasClass('qodef--active')) {
					$currentTrack.removeClass('qodef--active');
					
					qodefTracksList.triggerPlayerEvent($playerPlayList, $currentTrack.data('track-index'), 'pause');
					qodefCore.body.trigger('neobeat_core_trigger_tracks_list_event', [$holder.data('album-id'), $currentTrack.data('track-index'), 'pause']);
				} else {
					qodefTracksList.triggerPlayerEvent($playerPlayList, $currentTrack.data('track-index'), 'play');
					qodefCore.body.trigger('neobeat_core_trigger_tracks_list_event', [$holder.data('album-id'), $currentTrack.data('track-index'), 'play']);
				}
			});
		},
		setActiveTrack: function ($holder, $playerPlayList, event) {
			var activeSong = $playerPlayList.original[$playerPlayList.current].unique_id;
			
			$holder.find('.qodef-m-tracks-list-item').removeClass('qodef--active');
			
			if (event !== 'pause') {
				$holder.find('.qodef-m-tracks-list-item[data-track-id="' + activeSong + '"]').addClass('qodef--active');
			}
		},
		triggerPlayerEvent: function ($playerPlayList, trackID, event) {
			if (!qodefCore.body.hasClass('single-album')) {
				switch (event) {
					case 'pause':
						$playerPlayList.pause(trackID);
						break;
					case 'play':
						$playerPlayList.play(trackID);
						break;
				}
			}
		}
	};
	
	qodefCore.shortcodes.neobeat_core_tracks_list.qodefTracksList = qodefTracksList;
	
})(jQuery);
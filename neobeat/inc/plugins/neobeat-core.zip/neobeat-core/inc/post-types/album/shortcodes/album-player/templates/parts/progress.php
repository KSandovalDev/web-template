<div class="qodef-m-track-progress jp-gui jp-interface">
	<div class="jp-progress">
		<div class="jp-seek-bar">
			<div class="jp-play-bar"></div>
		</div>
	</div>
</div>
<?php

if ( ! function_exists( 'neobeat_core_add_artists_list_shortcode' ) ) {
	/**
	 * Function that isadding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function neobeat_core_add_artists_list_shortcode( $shortcodes ) {
		$shortcodes[] = 'NeoBeatCoreArtistsListShortcode';
		
		return $shortcodes;
	}
	
	add_filter( 'neobeat_core_filter_register_shortcodes', 'neobeat_core_add_artists_list_shortcode' );
}

if ( class_exists( 'NeoBeatCoreListShortcode' ) ) {
	class NeoBeatCoreArtistsListShortcode extends NeoBeatCoreListShortcode {
		
		public function __construct() {
			$this->set_layouts( apply_filters( 'neobeat_core_filter_artists_list_layouts', array() ) );
			$this->set_extra_options( apply_filters( 'neobeat_core_filter_artists_list_extra_options', array() ) );
		
			parent::__construct();
		}
		
		public function map_shortcode() {
			$this->set_shortcode_path( NEOBEAT_CORE_CPT_URL_PATH . '/album/shortcodes/artists-list' );
			$this->set_base( 'neobeat_core_artists_list' );
			$this->set_name( esc_html__( 'Artists List', 'neobeat-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays list of artists', 'neobeat-core' ) );
			$this->set_category( esc_html__( 'NeoBeat Core', 'neobeat-core' ) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'custom_class',
				'title'      => esc_html__( 'Custom Class', 'neobeat-core' )
			) );
			$this->map_list_options( array(
				'include_columns'   => array(
					'8'=> esc_html__( 'Eight', 'neobeat-core'),
					'7'=> esc_html__( 'Seven', 'neobeat-core')
				),
			) );
			$this->map_query_options( array(
				'default_posts_per_page' => '9',
				'exclude_option'         => array( 'additional_params' ),
			) );
			$this->map_layout_options( array( 'layouts' => $this->get_layouts()));
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'enable_round_images',
				'title'      => esc_html__( 'Enable Round Images', 'neobeat-core' ),
				'options'    => neobeat_core_get_select_type_options_pool( 'yes_no', false ),
				'group'      => esc_html__( 'Layout', 'neobeat-core' )
			) );
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'shadow',
				'title'      => esc_html__( 'Shadow', 'neobeat-core' ),
				'options'    => neobeat_core_get_select_type_options_pool( 'yes_no', false ),
			) );
			$this->set_option( array(
				'field_type'    => 'select',
				'name'          => 'enable_appear',
				'title'         => esc_html__( 'Enable Appear Animation', 'neobeat-core' ),
				'default_value' => 'no',
				'options'       => neobeat_core_get_select_type_options_pool( 'no_yes', false ),
				'dependency'    => array(
					'hide' => array(
						'behavior' => array(
							'values'        => 'slider',
							'default_value' => ''
						)
					)
				),
			) );
			$this->set_option( array(
				'field_type'    => 'select',
				'name'          => 'enable_parallax',
				'title'         => esc_html__( 'Enable Parallax Scroll', 'neobeat-core' ),
				'default_value' => 'no',
				'options'       => neobeat_core_get_select_type_options_pool( 'no_yes', false ),
				'dependency'    => array(
					'hide' => array(
						'behavior' => array(
							'values'        => 'slider', 'masonry',
							'default_value' => ''
						)
					)
				),
			) );
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'additional_params',
				'title'      => esc_html__( 'Additional Params', 'neobeat-core' ),
				'options'    => array(
					''   => esc_html__( 'No', 'neobeat-core' ),
					'id' => esc_html__( 'Taxonomy IDs', 'neobeat-core' ),
				),
				'group'      => esc_html__( 'Query', 'neobeat-core' ),
			) );
			$this->set_option( array(
				'field_type'  => 'text',
				'name'        => 'taxonomy_ids',
				'title'       => esc_html__( 'Taxonomy IDs', 'neobeat-core' ),
				'description' => esc_html__( 'Separate taxonomy IDs with commas', 'neobeat-core' ),
				'group'       => esc_html__( 'Query', 'neobeat-core' ),
				'dependency'  => array(
					'show' => array(
						'additional_params' => array(
							'values'        => 'id',
							'default_value' => '',
						)
					)
				),
			) );
			$this->map_extra_options();
		}
		
		public function render( $options, $content = null ) {
			parent::render( $options );
			
			$atts = $this->get_atts();
			
			$atts['taxonomy']       = 'artist';
			$atts['taxonomy_items'] = get_terms( neobeat_core_get_custom_post_type_taxonomy_query_args( $atts ) );
			
			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['item_classes']   = $this->get_item_classes( $atts );
			$atts['slider_attr']    = $this->get_slider_data( $atts, array( 'centeredSlides' => 'true' ) );
			
			$atts['this_shortcode'] = $this;
			
			return neobeat_core_get_template_part( 'post-types/album/shortcodes/artists-list', 'templates/content', $atts['behavior'], $atts );
		}
		
		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();
			
			$holder_classes[] = 'qodef-artists-list';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-layout--' . $atts['layout'] : '';
			$holder_classes[] = ( $atts['enable_parallax'] == 'yes' ) ? 'qodef-parallax-scroll' : '';
			
			if ( isset( $atts['enable_round_images'] ) && $atts['enable_round_images'] == 'yes' ) {
				$holder_classes[] = 'qodef-round-images';
			}
			
			if ( isset( $atts['enable_dark_skin'] ) && $atts['enable_dark_skin'] == 'yes' ) {
				$holder_classes[] = 'qodef-dark-skin';
			}
			
			$list_classes   = $this->get_list_classes( $atts );
			$holder_classes = array_merge( $holder_classes, $list_classes );
			
			return implode( ' ', $holder_classes );
		}
		
		public function get_item_classes( $atts ) {
			$item_classes = $this->init_item_classes();
			
			$item_classes[] = ( $atts['enable_appear'] == 'yes' ) ? 'qodef--has-appear': '';
			
			$list_item_classes   = $this->get_list_item_classes( $atts );
			
			$item_classes = array_merge( $item_classes, $list_item_classes );
			
			return implode( ' ', $item_classes );
		}
		
		public function get_title_styles( $atts ) {
			$styles = array();
			
			if ( ! empty( $atts['text_transform'] ) ) {
				$styles[] = 'text-transform: ' . $atts['text_transform'];
			}
			
			return $styles;
		}
	}
}
<?php

if ( ! empty( $tracks ) ) {
	foreach ( $tracks as $key => $track ) {
		$track_classes = array();
		
		$link_type = $track['qodef_album_single_track_link_type'];
		if ( ! empty( $link_type ) ) {
			$track_classes[] = 'qodef--' . $link_type;
		}
		
		$title        = $track['qodef_album_single_track_title'];
		$track_file   = ! empty( $track['qodef_album_single_track_file'] ) ? $track['qodef_album_single_track_file'] : '';
		$track_meta   = ! empty( $track_file ) ? wp_get_attachment_metadata( $track_file ) : '';
		$track_length = ! empty( $track_meta ) && isset( $track_meta['length_formatted'] ) && ! empty( $track_meta['length_formatted'] ) ? $track_meta['length_formatted'] : '';
		$track_info = $track['qodef_album_single_track_additional_info'];
		?>
		<div class="qodef-m-tracks-list-item qodef-e <?php echo esc_attr( implode( ' ', $track_classes ) ); ?>" data-track-id="<?php echo intval( $track_file ); ?>" data-track-index="<?php echo intval( $key ); ?>">
			<?php if ( ! empty( $title ) ) { ?>
				<div class="qodef-e-spinner">
					<?php echo qode_framework_icons()->render_icon( 'icon-music-record', 'linea-icons', array( 'icon_attributes' => array( 'class' => 'qodef-e-spinner-icon' ) ) ); ?>
				</div>
				<div class="qodef-e-heading">
					<h5 class="qodef-e-heading-title" title="<?php esc_attr_e( 'Click to play', 'neobeat-core' ); ?>">
						<span class="qodef-e-heading-title-number"><?php echo intval( $key ) + 1; ?></span>
						<span class="qodef-e-heading-title-label"><?php echo esc_html( $title ); ?></span>
					</h5>
					<?php if ( ! empty( $track_info ) ) { ?>
						<span class="qodef-e-heading-info"><?php echo wp_kses_post( $track_info ); ?></span>
					<?php } ?>
				</div>
				<div class="qodef-e-action">
					<?php if ( ! empty( $track_length ) ) { ?>
						<span class="qodef-e-action-track-length"><?php echo esc_html( $track_length ); ?></span>
					<?php } ?>
					<?php
					$actions = array();
					
					if ( ! empty( $link_type ) ) {
						switch ( $link_type ) {
							case 'free-download':
								$actions[ $link_type ] = array(
									'custom_class' => 'qodef--free-download',
									'title'        => esc_attr__( 'Free Download', 'neobeat-core' ),
									'link'         => ! empty( $track_file ) ? wp_get_attachment_url( $track_file ) : '',
									'target'       => '_self',
									'custom_attrs' => array( 'download' ),
									'icon'         => array( 'download' )
								);
								break;
							case 'buy-track':
								$actions[ $link_type ] = array(
									'custom_class' => 'qodef--buy-track',
									'title'        => esc_attr__( 'Buy Track', 'neobeat-core' ),
									'link'         => $track['qodef_album_single_track_buy_track_link'],
									'target'       => $track['qodef_album_single_track_buy_track_link_target'],
									'custom_attrs' => array(),
									'icon'         => array( 'shopping-bag' )
								);
								break;
						}
					}
					
					$actions['play'] = array(
						'custom_class' => 'qodef--play',
						'title'        => esc_attr__( 'Click to play', 'neobeat-core' ),
						'link'         => '#',
						'target'       => '_self',
						'custom_attrs' => array(),
						'icon'         => array( 'play', 'pause' )
					);
					
					foreach ( $actions as $action ) { ?>
						<a class="qodef-e-action-control <?php echo esc_attr( $action['custom_class'] ); ?>" href="<?php echo esc_url( $action['link'] ); ?>" target="<?php echo esc_attr( $action['target'] ); ?>" title="<?php echo esc_attr( $action['title'] ); ?>" <?php echo esc_attr( implode( ' ', $action['custom_attrs'] ) ); ?>>
							<?php foreach ( $action['icon'] as $icon ) {
								neobeat_core_template_part( 'post-types/album', 'templates/parts/icons/' . $icon, '', array( 'icon_class' => 'qodef-e-action-control-icon' ) );
							} ?>
						</a>
					<?php } ?>
				</div>
			<?php } ?>
		</div>
	<?php }
} ?>
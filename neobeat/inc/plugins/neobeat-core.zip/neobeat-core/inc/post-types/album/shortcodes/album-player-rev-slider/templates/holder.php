<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<?php
	if ( ! empty( $slider_alias ) ) {
		echo do_shortcode( '[rev_slider alias="' . esc_attr( $slider_alias ) . '"][/rev_slider]' );
	}
	
	if ( class_exists( 'NeoBeatCoreAlbumPlayerShortcode' ) ) { ?>
		<div class="qodef-content-grid">
			<?php $params = array(
				'layout' => 'standard',
				'album'  => $album,
				'skin'   => $skin,
			);
			
			echo NeoBeatCoreAlbumPlayerShortcode::call_shortcode( $params ); ?>
		</div>
	<?php }	?>
</div>
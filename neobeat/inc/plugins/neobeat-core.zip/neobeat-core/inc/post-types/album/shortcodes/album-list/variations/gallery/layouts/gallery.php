<div <?php qode_framework_class_attribute( $item_classes ); ?>>
	<div class="qodef-e-holder qodef-e-blur-trigger">
			<?php neobeat_core_list_sc_template_part( 'post-types/album/shortcodes/album-list', 'post-info/image', '', $params ); ?>
			<?php neobeat_core_list_sc_template_part( 'post-types/album/shortcodes/album-list', 'post-info/link', '', $params ); ?>
		<div class="qodef-e-inner">
			<?php neobeat_core_list_sc_template_part( 'post-types/album/shortcodes/album-list', 'post-info/title', '', $params ); ?>
			<?php neobeat_core_list_sc_template_part( 'post-types/album/shortcodes/album-list', 'post-info/artist', '', $params ); ?>
		</div>
	</div>
	<?php neobeat_core_list_sc_template_part( 'post-types/album/shortcodes/album-list', 'post-info/stores', '', $params ); ?>
</div>

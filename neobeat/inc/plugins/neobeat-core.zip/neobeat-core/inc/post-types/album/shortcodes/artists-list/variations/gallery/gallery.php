<?php

if ( ! function_exists( 'neobeat_core_add_artists_list_variation_gallery' ) ) {
	function neobeat_core_add_artists_list_variation_gallery( $variations ) {
		$variations['gallery'] = esc_html__( 'Gallery', 'neobeat-core' );
		
		return $variations;
	}
	
	add_filter( 'neobeat_core_filter_artists_list_layouts', 'neobeat_core_add_artists_list_variation_gallery' );
}
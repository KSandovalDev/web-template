<?php if ( has_post_thumbnail( $album ) ) { ?>
	<div class="qodef-m-album-image">
		<?php echo get_the_post_thumbnail( $album, 'full' ); ?>
	</div>
<?php } ?>
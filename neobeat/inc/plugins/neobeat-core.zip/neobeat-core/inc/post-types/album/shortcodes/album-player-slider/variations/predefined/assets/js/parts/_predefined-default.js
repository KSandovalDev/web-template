(function ($) {
	"use strict";
	
	$(document).ready(function () {
		qodefAlbumSlider.init();
	});
	
	var qodefAlbumSlider = {
		init: function () {
			var $holder = $('.qodef-album-player-slider.qodef-layout--predefined.qodef-swiper-container'),
				$imgHolder = $('.qodef-album-player-slider.qodef-layout--predefined.qodef-swiper-container .swiper-wrapper .swiper-slide .qodef-e-media-image');
			
			if ($imgHolder.length) {
				$imgHolder.each(function () {
					var thisHolder = $(this),
						maxWidth = thisHolder.width();
					
					thisHolder.css({
						'max-height': maxWidth,
						'max-width': maxWidth,
					});
				});
			}
			
			if ($holder.length) {
				$holder.each(function () {
					var $thisHolder = $(this),
						$thisItems = $thisHolder.find('.swiper-slide');
					
					// Init SVG Circle Animation for each item
					$thisItems.each(function(i) {
						i++;
						var $thisItem = $(this),
							$thisSVG = $thisItem.find('.qodef--background-svg');

						if ($thisSVG.length) {
							$thisSVG.find('linearGradient').attr("id","qodef-svg-gradient-"+ i );
							var thisItemAnimationData = qodefAlbumSlider.initWave($thisSVG, i);
							$thisItem.data('animation-data', thisItemAnimationData);
						}
					});

					// Swiper slider - animate active item only
					qodefAlbumSlider.animateActiveItemWave($thisHolder, $thisItems);
				});
			}
		},
		animateActiveItemWave: function($swiperHolder, $items) {
			var thisSwiper = $swiperHolder[0].swiper,
				animateFunction = function() {
					$items.each(function() {
						var $thisItem = $(this),
							thisItemAnimationData = $(this).data('animation-data');
						
						if (thisItemAnimationData) {
							var animateWave = function() {
								if (!$thisItem.hasClass('swiper-slide-active')) return;
								thisItemAnimationData.animateSVG();
								window.requestAnimationFrame(animateWave);
							}
							animateWave();
						}
					});
				}

			thisSwiper.on('slideChange', function () {
				setTimeout(function() {
					animateFunction();
				}, 100);
			});
			
			$(document).ready(function () {
				setTimeout(function() {
					animateFunction();
				}, 100);
			});
		},
		initWave: function (itemSVG, svgIndex) {
			var svg = d3.selectAll(itemSVG),
				svgWidth = itemSVG.width(),
			    svgHeight = itemSVG.height(),
				width = svgWidth,
				height = svgHeight,
				angles = d3.range(0, 2 * Math.PI, Math.PI / 300);
			
			var path = svg
				.append("g")
				.attr("transform", "translate(" + width / 2 + "," + height / 2 + ")")
				.attr("fill", "none")
				.attr("stroke-width", 1)
				.attr("stroke-linejoin", "round")
				.selectAll("path")
				.data(["url(#qodef-svg-gradient-" + svgIndex + ")"])
				.enter()
				.append("path")
				.attr("stroke", function (d) {
					return d;
				})
				.datum(function (d, i) {
					return d3
						.radialLine()
						.curve(d3.curveLinearClosed)
						.angle(function (a) {
							return a * -1;
						})
						.radius(function (a) {
							var t = d3.now() / 500;
							return (
								width/4 + width/6 +
								Math.cos(a * 12 - (i * 2 * Math.PI) / 3 + t ) *
								Math.pow((1 + Math.cos(a * 10 - t )) / 2, 2) *
								20
							);
						});
				});

			var animateSVG = function () {
				path.attr("d", function (d) {
					return d(angles);
				});
			};

			animateSVG(); // used to initially position svg

			return {
				animateSVG: animateSVG
			}
		}
	};
	
	qodefCore.shortcodes.neobeat_core_album_player_slider.qodefAlbumSlider = qodefAlbumSlider;
	
})(jQuery);
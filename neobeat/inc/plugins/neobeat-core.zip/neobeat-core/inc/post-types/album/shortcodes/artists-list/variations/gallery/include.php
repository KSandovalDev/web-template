<?php

include_once NEOBEAT_CORE_CPT_PATH . '/album/shortcodes/artists-list/variations/gallery/gallery.php';
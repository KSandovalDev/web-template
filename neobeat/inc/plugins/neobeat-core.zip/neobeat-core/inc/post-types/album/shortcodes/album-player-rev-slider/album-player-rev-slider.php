<?php

if ( ! function_exists( 'neobeat_core_add_album_player_rev_slider_shortcode' ) ) {
	/**
	 * Function that isadding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function neobeat_core_add_album_player_rev_slider_shortcode( $shortcodes ) {
		$shortcodes[] = 'NeoBeatCoreAlbumPlayerRevSliderShortcode';
		
		return $shortcodes;
	}
	
	add_filter( 'neobeat_core_filter_register_shortcodes', 'neobeat_core_add_album_player_rev_slider_shortcode' );
}

if ( class_exists( 'NeoBeatCoreShortcode' ) ) {
	class NeoBeatCoreAlbumPlayerRevSliderShortcode extends NeoBeatCoreShortcode {
		
		public function map_shortcode() {
			$this->set_shortcode_path( NEOBEAT_CORE_CPT_URL_PATH . '/album/shortcodes/album-player-rev-slider' );
			$this->set_base( 'neobeat_core_album_player_rev_slider' );
			$this->set_name( esc_html__( 'Album Player Revolution Slider', 'neobeat-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays player of album inside revolution slider', 'neobeat-core' ) );
			$this->set_category( esc_html__( 'NeoBeat Core', 'neobeat-core' ) );
			
			$this->set_scripts(
				array(
					'jplaylist' => array(
						'registered'	=> false,
						'url'			=> NEOBEAT_CORE_CPT_URL_PATH . '/album/shortcodes/album-player/assets/js/plugins/jplayer.playlist.min.js',
						'dependency'	=> array( 'jquery' )
					),
					'jplayer' => array(
						'registered'	=> false,
						'url'			=> NEOBEAT_CORE_CPT_URL_PATH . '/album/shortcodes/album-player/assets/js/plugins/jquery.jplayer.min.js',
						'dependency'	=> array( 'jquery' )
					)
				)
			);
			
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'custom_class',
				'title'      => esc_html__( 'Custom Class', 'neobeat-core' ),
			) );
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'slider_alias',
				'title'      => esc_html__( 'Revolution Slider', 'neobeat-core' ),
				'options'    => neobeat_core_get_album_revolution_sliders_array(),
			) );
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'album',
				'title'      => esc_html__( 'Album', 'neobeat-core' ),
				'options'    => qode_framework_get_cpt_items( 'album' ),
			) );
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'skin',
				'title'      => esc_html__( 'Album Skin', 'neobeat-core' ),
				'options'    => array(
					''      => esc_html__( 'Default', 'neobeat-core' ),
					'light' => esc_html__( 'Light', 'neobeat-core' ),
				),
			) );
		}
		
		public function load_assets() {
			wp_enqueue_script( 'jplaylist' );
			wp_enqueue_script( 'jplayer' );
		}
		
		public function render( $options, $content = null ) {
			parent::render( $options );
			
			$atts = $this->get_atts();
			
			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			
			return neobeat_core_get_template_part( 'post-types/album/shortcodes/album-player-rev-slider', '/templates/holder', '', $atts );
		}
		
		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();
			
			$holder_classes[] = 'qodef-album-player-rev-slider';
			
			return implode( ' ', $holder_classes );
		}
	}
}
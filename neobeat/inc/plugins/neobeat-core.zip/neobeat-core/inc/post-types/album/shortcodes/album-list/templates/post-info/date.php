<?php
$album_date = get_post_meta( get_the_ID(), 'qodef_album_single_release_date', true );

if ( ! empty( $album_date ) ) {
	$date = explode( '-', $album_date );
	?>
	<span class="qodef-e-date">
		<?php echo date( get_option( 'date_format' ), mktime( 0, 0, 0, $date[1], $date[2], $date[0] ) ); ?>
	</span>
<?php }
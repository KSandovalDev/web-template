<div class="qodef-m-spinner">
	<?php echo qode_framework_icons()->render_icon( 'icon-music-record', 'linea-icons', array( 'icon_attributes' => array( 'class' => 'qodef-m-spinner-icon' ) ) ); ?>
</div>
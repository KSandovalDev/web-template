<?php

if ( ! function_exists( 'neobeat_core_generate_album_single_layout' ) ) {
	function neobeat_core_generate_album_single_layout() {
		$template = neobeat_core_get_post_value_through_levels( 'qodef_album_single_layout' );
		
		return ! empty( $template ) ? $template : '';
	}
	
	add_filter( 'neobeat_core_filter_album_single_layout', 'neobeat_core_generate_album_single_layout' );
}

if ( ! function_exists( 'neobeat_core_get_album_holder_classes' ) ) {
	/**
	 * Function that return classes for the main album holder
	 *
	 * @return string
	 */
	function neobeat_core_get_album_holder_classes() {
		$classes = array( 'qodef-album-single' );
		
		$item_layout = neobeat_core_generate_album_single_layout();
		if ( ! empty( $item_layout ) ) {
			$classes[] = 'qodef-item-layout--' . $item_layout;
		}
		
		return implode( ' ', $classes );
	}
}

if ( ! function_exists( 'neobeat_core_set_album_single_body_classes' ) ) {
	/**
	 * Function that return classes for the single custom post type
	 *
	 * @return array $classes
	 */
	function neobeat_core_set_album_single_body_classes( $classes ) {
		$item_layout = neobeat_core_generate_album_single_layout();
		
		if ( is_singular( 'album' ) && ! empty( $item_layout ) ) {
			$classes[] = 'qodef-album-single-layout--' . $item_layout;
		}
		
		return $classes;
	}
	
	add_filter( 'body_class', 'neobeat_core_set_album_single_body_classes' );
}

if ( ! function_exists( 'neobeat_core_generate_album_archive_with_shortcode' ) ) {
	/**
	 * Function that executes album list shortcode with params on archive pages
	 *
	 * @param string $tax - type of taxonomy
	 * @param string $tax_slug - slug of taxonomy
	 * @param array $additional_params
	 */
	function neobeat_core_generate_album_archive_with_shortcode( $tax, $tax_slug, $additional_params = array() ) {
		$params = array();
		
		$params['additional_params']  = 'tax';
		$params['tax']                = $tax;
		$params['tax_slug']           = $tax_slug;
		
		if ( ! empty( $additional_params ) ) {
			$params = array_merge( $params, $additional_params );
		}
		
		echo NeoBeatCoreAlbumListShortcode::call_shortcode( $params );
	}
}

if ( ! function_exists( 'neobeat_core_album_set_admin_options_map_position' ) ) {
	/**
	 * Function that set dashboard admin options map position for this module
	 *
	 * @param $position int
	 * @param $map string
	 *
	 * @return int
	 */
	function neobeat_core_album_set_admin_options_map_position( $position, $map ) {
		
		if ( $map === 'album' ) {
			$position = 60;
		}
		
		return $position;
	}
	
	add_filter( 'neobeat_core_filter_admin_options_map_position', 'neobeat_core_album_set_admin_options_map_position', 10, 2 );
}

if ( ! function_exists( 'neobeat_core_album_register_artist_archive_template' ) ) {
	/**
	 * Registers portfolio archive template if one does'nt exists in theme.
	 * Hooked to archive_template filter
	 *
	 * @param $archive string current template
	 *
	 * @return string string changed template
	 */
	function neobeat_core_album_register_artist_archive_template( $archive ) {
		$queried_tax = get_queried_object();
		
		if ( ! empty( $queried_tax ) && $queried_tax->taxonomy == 'artist' && file_exists( NEOBEAT_CORE_CPT_PATH . '/album/templates/taxonomy-artist.php' ) ) {
			$archive = NEOBEAT_CORE_CPT_PATH . '/album/templates/taxonomy-artist.php';
		}
	
		return $archive;
	}
	
	add_filter( 'taxonomy_template', 'neobeat_core_album_register_artist_archive_template' );
}

if ( ! function_exists( 'neobeat_core_set_artist_single_page_title_text' ) ) {
	/**
	 * Function that set current post title text
	 *
	 * @param $title string
	 *
	 * @return string
	 */
	function neobeat_core_set_artist_single_page_title_text( $title ) {
		
		if ( is_tax( 'artist' ) ) {
			$title = esc_html__( 'Artist', 'neobeat-core' );
		}
		
		return $title;
	}
	
	add_filter( 'neobeat_filter_page_title_text', 'neobeat_core_set_artist_single_page_title_text' );
}

if ( ! function_exists( 'neobeat_core_album_breadcrumbs_title' ) ) {
	/**
	 * Improve main breadcrumbs template with additional cases
	 *
	 * @param string|html $wrap_child
	 * @param array $settings
	 *
	 * @return string|html
	 */
	function neobeat_core_album_breadcrumbs_title( $wrap_child, $settings ) {
		if ( is_tax( 'genre' ) ) {
			$wrap_child  = '';
			$term_object = get_term( get_queried_object_id(), 'genre' );
			
			if ( isset( $term_object->parent ) && $term_object->parent !== 0 ) {
				$parent     = get_term( $term_object->parent );
				$wrap_child .= sprintf( $settings['link'], get_term_link( $parent->term_id ), $parent->name ) . $settings['separator'];
			}
			
			$wrap_child .= sprintf( $settings['current_item'], single_cat_title( '', false ) );
		}if ( is_tax( 'album-label' ) ) {
			$wrap_child  = '';
			$term_object = get_term( get_queried_object_id(), 'album-label' );
			
			if ( isset( $term_object->parent ) && $term_object->parent !== 0 ) {
				$parent     = get_term( $term_object->parent );
				$wrap_child .= sprintf( $settings['link'], get_term_link( $parent->term_id ), $parent->name ) . $settings['separator'];
			}
			
			$wrap_child .= sprintf( $settings['current_item'], single_cat_title( '', false ) );
		} elseif ( is_tax( 'artist' ) ) {
			$wrap_child  = '';
			$term_object = get_term( get_queried_object_id(), 'artist' );
			
			if ( isset( $term_object->parent ) && $term_object->parent !== 0 ) {
				$parent     = get_term( $term_object->parent );
				$wrap_child .= sprintf( $settings['link'], get_term_link( $parent->term_id ), $parent->name ) . $settings['separator'];
			}
			
			$wrap_child .= sprintf( $settings['current_item'], single_cat_title( '', false ) );
		} elseif ( is_singular( 'album' ) ) {
			$wrap_child = '';
			$post_terms = wp_get_post_terms( get_the_ID(), 'artist' );
			
			if ( ! empty ( $post_terms ) ) {
				$post_term = $post_terms[0];
				if ( isset( $post_term->parent ) && $post_term->parent !== 0 ) {
					$parent     = get_term( $post_term->parent );
					$wrap_child .= sprintf( $settings['link'], get_term_link( $parent->term_id ), $parent->name ) . $settings['separator'];
				}
				$wrap_child .= sprintf( $settings['link'], get_term_link( $post_term ), $post_term->name ) . $settings['separator'];
			}
			
			$wrap_child .= sprintf( $settings['current_item'], get_the_title() );
		}
		
		return $wrap_child;
	}
	
	add_filter( 'neobeat_core_filter_breadcrumbs_content', 'neobeat_core_album_breadcrumbs_title', 10, 2 );
}
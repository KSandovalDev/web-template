<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<div id="qodef-m-album-<?php echo intval( $album ); ?>" class="qodef-m-album jp-jplayer" data-album-id="<?php echo intval( $album ); ?>"></div>
	<?php neobeat_core_template_part( 'post-types/album/shortcodes/album-player', '/templates/parts/album-image', '', $params ); ?>
	<div id="qodef-m-player-<?php echo intval( $album ); ?>" class="qodef-m-player">
		<div class="qodef-m-player-heading">
			<?php neobeat_core_template_part( 'post-types/album/shortcodes/album-player', '/templates/parts/track-title' ); ?>
		</div>
		<div class="qodef-m-player-middle">
			<?php neobeat_core_template_part( 'post-types/album/shortcodes/album-player', '/templates/parts/progress' ); ?>
			<?php neobeat_core_template_part( 'post-types/album/shortcodes/album-player', '/templates/parts/track-duration' ); ?>
			<?php neobeat_core_template_part( 'post-types/album/shortcodes/album-player', '/templates/parts/controls' ); ?>
			<?php neobeat_core_template_part( 'post-types/album/shortcodes/album-player', '/templates/parts/volume-control' ); ?>
		</div>
		<div class="qodef-m-player-footer">
			<?php neobeat_core_template_part( 'post-types/album/shortcodes/album-player', '/templates/parts/album-title', '', $params ); ?>
		</div>
		<?php neobeat_core_template_part( 'post-types/album/shortcodes/album-player', '/templates/parts/playlist' ); ?>
	</div>
</div>
<?php

include_once NEOBEAT_CORE_CPT_PATH . '/album/shortcodes/album-player/helper.php';
include_once NEOBEAT_CORE_CPT_PATH . '/album/shortcodes/album-player/album-player.php';

foreach ( glob( NEOBEAT_CORE_CPT_PATH . '/album/shortcodes/album-player/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
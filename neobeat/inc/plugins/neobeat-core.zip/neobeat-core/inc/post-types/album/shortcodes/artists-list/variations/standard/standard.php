<?php

if ( ! function_exists( 'neobeat_core_add_artists_list_variation_standard' ) ) {
	function neobeat_core_add_artists_list_variation_standard( $variations ) {
		$variations['standard'] = esc_html__( 'Standard', 'neobeat-core' );
		
		return $variations;
	}
	
	add_filter( 'neobeat_core_filter_artists_list_layouts', 'neobeat_core_add_artists_list_variation_standard' );
}

if ( ! function_exists( 'neobeat_core_add_artists_list_options_standard' ) ) {
	function neobeat_core_add_artists_list_options_standard( $options ) {
		$predefined_options   = array();
		$dark_option      = array(
			'field_type' => 'select',
			'name'       => 'enable_dark_skin',
			'title'      => esc_html__( 'Enable Dark Skin', 'neobeat-core' ),
			'dependency' => array(
				'show' => array(
					'layout' => array(
						'values'        => 'standard',
						'values'        => array( 'standard', 'predefined' ),
						'default_value' => 'default'
					)
				)
			),
			'options'    => neobeat_core_get_select_type_options_pool( 'no_yes', false ),
			'group'      => esc_html__( 'Layout', 'neobeat-core' )
		);
		$predefined_options [] = $dark_option;
		
		return array_merge( $options, $predefined_options );
	}
	
	add_filter( 'neobeat_core_filter_artists_list_extra_options', 'neobeat_core_add_artists_list_options_standard' );
}
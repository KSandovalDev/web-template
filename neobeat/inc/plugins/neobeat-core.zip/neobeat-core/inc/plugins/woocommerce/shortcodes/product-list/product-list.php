<?php

if ( ! function_exists( 'neobeat_core_add_product_list_shortcode' ) ) {
	/**
	 * Function that is adding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function neobeat_core_add_product_list_shortcode( $shortcodes ) {
		$shortcodes[] = 'NeoBeatCoreProductListShortcode';
		
		return $shortcodes;
	}
	
	add_filter( 'neobeat_core_filter_register_shortcodes', 'neobeat_core_add_product_list_shortcode' );
}

if ( class_exists( 'NeoBeatCoreListShortcode' ) ) {
	class NeoBeatCoreProductListShortcode extends NeoBeatCoreListShortcode {
		
		public function __construct() {
			$this->set_post_type( 'product' );
			$this->set_post_type_taxonomy( 'product_cat' );
			$this->set_post_type_additional_taxonomies( array( 'product_tag', 'product_type' ) );
			$this->set_layouts( apply_filters( 'neobeat_core_filter_product_list_layouts', array() ) );
			$this->set_extra_options( apply_filters( 'neobeat_core_filter_product_list_extra_options', array() ) );
			
			parent::__construct();
		}
		
		public function map_shortcode() {
			$this->set_shortcode_path( NEOBEAT_CORE_PLUGINS_URL_PATH . '/woocommerce/shortcodes/product-list' );
			$this->set_base( 'neobeat_core_product_list' );
			$this->set_name( esc_html__( 'Product List', 'neobeat-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays list of products', 'neobeat-core' ) );
			$this->set_category( esc_html__( 'NeoBeat Core', 'neobeat-core' ) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'custom_class',
				'title'      => esc_html__( 'Custom Class', 'neobeat-core' )
			) );
			$this->map_list_options();
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'side_offset',
				'title'      => esc_html__( 'Enable Side Offset', 'neobeat-core' ),
				'options'    => neobeat_core_get_select_type_options_pool( 'no_yes', false ),
				'dependency' => array(
					'show' => array(
						'behavior' => array(
							'values'        => 'slider',
							'default_value' => ''
						)
					)
				)
			) );
			$this->set_option( array(
				'field_type'    => 'select',
				'name'          => 'offset',
				'title'         => esc_html__( 'Column Vertical Offset', 'neobeat-core' ),
				'description'   => esc_html__( 'This option will work only when number of columns is three or four and list is gallery', 'neobeat-core' ),
				'options'       => neobeat_core_get_select_type_options_pool( 'no_yes', false ),
				'dependency' => array(
					'show' => array(
						'behavior' => array(
							'values' => 'columns',
							'default_value' => ''
						)
					)
				)
			) );
			$this->set_option( array(
				'field_type'    => 'select',
				'name'          => 'enable_blur',
				'title'         => esc_html__( 'Enable Hover Blur', 'neobeat-core' ),
				'default_value' => 'yes',
				'options'       => neobeat_core_get_select_type_options_pool( 'yes_no', false ),
			) );
			$this->map_query_options( array( 'post_type' => $this->get_post_type() ) );
			$this->set_option( array(
				'field_type'    => 'select',
				'name'          => 'filterby',
				'title'         => esc_html__( 'Filter By', 'neobeat-core' ),
				'options'       => array(
					''             => esc_html__( 'Default', 'neobeat-core' ),
					'on_sale'      => esc_html__( 'On Sale', 'neobeat-core' ),
					'featured'     => esc_html__( 'Featured', 'neobeat-core' ),
					'top_rated'    => esc_html__( 'Top Rated', 'neobeat-core' ),
					'best_selling' => esc_html__( 'Best Selling', 'neobeat-core' )
				),
				'default_value' => '',
				'group'         => esc_html__( 'Query', 'neobeat-core' ),
				'dependency'    => array(
					'show' => array(
						'additional_params' => array(
							'values'        => '',
							'default_value' => ''
						)
					)
				)
			) );
			$this->set_option( array(
				'field_type'    => 'select',
				'name'          => 'hide_rating',
				'title'         => esc_html__( 'Hide Rating Stars', 'neobeat-core' ),
				'options'       => neobeat_core_get_select_type_options_pool( 'no_yes' ),
				'default_value' => 'no',
				'group'         => esc_html__( 'Layout', 'neobeat-core' )
			) );
			$this->map_layout_options( array( 'layouts' => $this->get_layouts() ) );
			$this->map_additional_options();
			$this->map_extra_options();
		}
		
		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'neobeat_core_product_list', $params );
			$html = str_replace( "\n", '', $html );
			
			return $html;
		}
		
		public function render( $options, $content = null ) {
			parent::render( $options );
			
			$atts = $this->get_atts();
			
			$atts['post_type']       = $this->get_post_type();
			$atts['taxonomy_filter'] = $this->get_post_type_taxonomy();
			
			// Additional query args
			$atts['additional_query_args'] = $this->get_additional_query_args( $atts );
			
			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['query_result']   = new \WP_Query( neobeat_core_get_query_params( $atts ) );
			$atts['slider_attr']    = $this->get_slider_data( $atts );
			$atts['data_attr']      = neobeat_core_get_pagination_data( NEOBEAT_CORE_REL_PATH, 'plugins/woocommerce/shortcodes', 'product-list', 'product', $atts );
			
			$atts['this_shortcode'] = $this;
			
			return neobeat_core_get_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/content', $atts['behavior'], $atts );
		}
		
		public function get_additional_query_args( $atts ) {
			$args = parent::get_additional_query_args( $atts );
			
			if ( ! empty( $atts['filterby'] ) ) {
				switch ( $atts['filterby'] ) {
					case 'on_sale':
						$args['no_found_rows'] = 1;
						$args['post__in']      = array_merge( array( 0 ), wc_get_product_ids_on_sale() );
						break;
					case 'featured':
						$args['tax_query'] = WC()->query->get_tax_query();
						
						$args['tax_query'][] = array(
							'taxonomy'         => 'product_visibility',
							'terms'            => 'featured',
							'field'            => 'name',
							'operator'         => 'IN',
							'include_children' => false,
						);
						break;
					case 'top_rated':
						$args['meta_key'] = '_wc_average_rating';
						$args['order']    = 'DESC';
						$args['orderby']  = 'meta_value_num';
						break;
					case 'best_selling':
						$args['meta_key'] = 'total_sales';
						$args['order']    = 'DESC';
						$args['orderby']  = 'meta_value_num';
						break;
				}
			}
			
			return $args;
		}
		
		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();
			
			$holder_classes[] = 'qodef-woo-shortcode';
			$holder_classes[] = 'qodef-woo-product-list';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-item-layout--' . $atts['layout'] : '';
			$holder_classes[] = ! empty( $atts['side_offset'] ) & ( $atts['side_offset'] == 'yes' )? 'qodef-side-offset' : '';
			$holder_classes[] = $atts['offset'] == 'yes' && ( $atts['behavior'] == 'columns' ) && ( ( $atts['columns'] == '3' ) || ( $atts['columns'] == '4' ) ) ? 'qodef-vertical-offset' : '';
			$holder_classes[] = ! empty( $atts['enable_blur'] ) & ( $atts['enable_blur'] == 'yes' ) ? 'qodef--enabled-blur' : '';
			
			$list_classes   = $this->get_list_classes( $atts );
			$holder_classes = array_merge( $holder_classes, $list_classes );
			
			return implode( ' ', $holder_classes );
		}
		
		public function get_item_classes( $atts ) {
			$item_classes      = $this->init_item_classes();
			$list_item_classes = $this->get_list_item_classes( $atts );
			
			$item_classes = array_merge( $item_classes, $list_item_classes );
			
			return implode( ' ', $item_classes );
		}
		
		public function get_title_styles( $atts ) {
			$styles = array();
			
			if ( ! empty( $atts['text_transform'] ) ) {
				$styles[] = 'text-transform: ' . $atts['text_transform'];
			}
			
			return $styles;
		}
	}
}
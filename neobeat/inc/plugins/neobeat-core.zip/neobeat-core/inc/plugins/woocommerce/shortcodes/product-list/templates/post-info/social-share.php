<?php if ( class_exists( 'NeoBeatCoreSocialShareShortcode' ) ) { ?>
	<div class="qodef-woo-product-social-share">
		<?php
		$params = array();
		$params['title'] = esc_html__( 'Share:', 'neobeat-core' );
		
		echo NeoBeatCoreSocialShareShortcode::call_shortcode( $params ); ?>
	</div>
<?php } ?>
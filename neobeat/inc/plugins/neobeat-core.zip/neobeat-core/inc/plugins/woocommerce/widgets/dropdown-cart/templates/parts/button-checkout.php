<div class="qodef-m-action">
	<a itemprop="url" href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="qodef-m-action-link checkout"><?php esc_html_e( 'Checkout', 'neobeat-core' ); ?></a>
</div>
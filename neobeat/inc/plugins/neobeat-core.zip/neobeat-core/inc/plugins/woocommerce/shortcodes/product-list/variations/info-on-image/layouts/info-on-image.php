<?php
$hide_category = neobeat_core_get_post_value_through_levels( 'qodef_woo_hide_category_on_list' );
?>

<div <?php wc_product_class( $item_classes ); ?>>
    <div class="qodef-woo-product-inner qodef-e-blur-trigger">
		<?php if ( has_post_thumbnail() ) { ?>
            <div class="qodef-woo-product-image qodef-e-blur-target">
				<?php neobeat_core_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/post-info/on-sale' ); ?>
				<?php neobeat_core_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/post-info/image', '', $params ); ?>
                <div class="qodef-woo-product-image-inner">
	                <?php
	                if( $hide_category === 'no') {
		                neobeat_core_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/post-info/category', '', $params );
	                }
	                ?>
					<?php neobeat_core_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/post-info/title', '', $params ); ?>
	                <?php
	                if( $hide_rating === 'no') {
		                neobeat_core_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/post-info/rating', '', $params );
	                }?>
					<?php neobeat_core_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/post-info/price', '', $params ); ?>
					<?php neobeat_core_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/post-info/add-to-cart' ); ?>
                </div>
            </div>
		<?php } ?>
		<?php neobeat_core_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/post-info/link' ); ?>
    </div>
</div>
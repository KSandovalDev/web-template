<?php neobeat_core_template_part( 'plugins/woocommerce/widgets/dropdown-cart', 'templates/parts/opener' ); ?>
<div class="qodef-m-dropdown">
	<div class="qodef-m-dropdown-inner">
		<?php if ( ! WC()->cart->is_empty() ) {
			neobeat_core_template_part( 'plugins/woocommerce/widgets/dropdown-cart', 'templates/parts/loop' );
			
			neobeat_core_template_part( 'plugins/woocommerce/widgets/dropdown-cart', 'templates/parts/order-details' ); ?>
			<div class="qodef-m-buttons-holder">
			<?php
			neobeat_core_template_part( 'plugins/woocommerce/widgets/dropdown-cart', 'templates/parts/button-view-cart' );
			neobeat_core_template_part( 'plugins/woocommerce/widgets/dropdown-cart', 'templates/parts/button-checkout' );
			?>
			</div>
		<?php
		} else {
			neobeat_core_template_part( 'plugins/woocommerce/widgets/dropdown-cart', 'templates/parts/posts-not-found' );
		} ?>
	</div>
</div>
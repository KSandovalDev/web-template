<div <?php qode_framework_class_attribute( $holder_classes ); ?> <?php qode_framework_inline_attr( $slider_attr, 'data-options' ); ?>>
    <div class="swiper-wrapper">
		<?php
		// Include items
		neobeat_core_template_part( 'plugins/woocommerce/shortcodes/product-categories-list', 'templates/loop', '', $params );
		?>
    </div>
	<?php if ( $slider_navigation !== 'no' ) { ?>
		<div class="swiper-navigation">
			<div class="swiper-button-prev">
				<svg class="qodef-svg-circle"><circle cx="50%" cy="50%" r="45%"></circle></svg>
				<svg class="qodef-svg-circle"><circle cx="50%" cy="50%" r="45%"></circle></svg>
				<?php echo qode_framework_icons()->render_icon( 'ion-ios-arrow-back', 'ionicons')?>
			</div>
			<div class="swiper-button-next">
				<svg class="qodef-svg-circle"><circle cx="50%" cy="50%" r="45%"></circle></svg>
				<svg class="qodef-svg-circle"><circle cx="50%" cy="50%" r="45%"></circle></svg>
				<?php echo qode_framework_icons()->render_icon( 'ion-ios-arrow-forward', 'ionicons')?>
			</div>
		</div>
	<?php } ?>
	<?php if ( $slider_pagination !== 'no' ) { ?>
        <div class="swiper-pagination"></div>
	<?php } ?>
</div>
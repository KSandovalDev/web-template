<?php

include_once NEOBEAT_CORE_PLUGINS_PATH . '/woocommerce/woocommerce.php';
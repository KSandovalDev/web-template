<?php

include_once 'info-on-image.php';
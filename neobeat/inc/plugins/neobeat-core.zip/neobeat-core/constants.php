<?php

define( 'NEOBEAT_CORE_VERSION', '1.1.1' );
define( 'NEOBEAT_CORE_ABS_PATH', dirname( __FILE__ ) );
define( 'NEOBEAT_CORE_REL_PATH', dirname( plugin_basename( __FILE__ ) ) );
define( 'NEOBEAT_CORE_URL_PATH', plugin_dir_url( __FILE__ ) );
define( 'NEOBEAT_CORE_ASSETS_PATH', NEOBEAT_CORE_ABS_PATH . '/assets' );
define( 'NEOBEAT_CORE_ASSETS_URL_PATH', NEOBEAT_CORE_URL_PATH . 'assets' );
define( 'NEOBEAT_CORE_INC_PATH', NEOBEAT_CORE_ABS_PATH . '/inc' );
define( 'NEOBEAT_CORE_INC_URL_PATH', NEOBEAT_CORE_URL_PATH . 'inc' );
define( 'NEOBEAT_CORE_CPT_PATH', NEOBEAT_CORE_INC_PATH . '/post-types' );
define( 'NEOBEAT_CORE_CPT_URL_PATH', NEOBEAT_CORE_INC_URL_PATH . '/post-types' );
define( 'NEOBEAT_CORE_SHORTCODES_PATH', NEOBEAT_CORE_INC_PATH . '/shortcodes' );
define( 'NEOBEAT_CORE_SHORTCODES_URL_PATH', NEOBEAT_CORE_INC_URL_PATH . '/shortcodes' );
define( 'NEOBEAT_CORE_PLUGINS_PATH', NEOBEAT_CORE_INC_PATH . '/plugins' );
define( 'NEOBEAT_CORE_PLUGINS_URL_PATH', NEOBEAT_CORE_INC_URL_PATH . '/plugins' );
define( 'NEOBEAT_CORE_HEADER_LAYOUTS_PATH', NEOBEAT_CORE_INC_PATH . '/header/layouts' );
define( 'NEOBEAT_CORE_HEADER_LAYOUTS_URL_PATH', NEOBEAT_CORE_INC_URL_PATH . '/header/layouts' );
define( 'NEOBEAT_CORE_HEADER_ASSETS_PATH', NEOBEAT_CORE_INC_PATH . '/header/assets' );
define( 'NEOBEAT_CORE_HEADER_ASSETS_URL_PATH', NEOBEAT_CORE_INC_URL_PATH . '/header/assets' );

define( 'NEOBEAT_CORE_MENU_NAME', 'neobeat_core_menu' );
define( 'NEOBEAT_CORE_OPTIONS_NAME', 'neobeat_core_options' );

define( 'NEOBEAT_CORE_PROFILE_SLUG', 'elated' );